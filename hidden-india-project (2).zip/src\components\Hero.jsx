import React from 'react';
import { Compass, Map, Search, Sparkles, ArrowRight, ShieldCheck, Heart } from 'lucide-react';

export const Hero = ({ 
  searchTerm, 
  setSearchTerm, 
  onStartQuiz, 
  onOpenMap,
  totalDestinations 
}) => {
  return (
    <div className="relative overflow-hidden bg-sandstone-900 text-white pt-12 pb-20 lg:pt-20 lg:pb-28">
      {/* Background Ambient Imagery & Gradients */}
      <div className="absolute inset-0 z-0 opacity-40">
        <img 
          src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=2000&q=80" 
          alt="Majestic Indian landscape"
          className="w-full h-full object-cover object-center filter saturate-150"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-sandstone-950 via-sandstone-900/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-saffron-950/60 via-transparent to-peacock-950/60" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Announcement Pill */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs sm:text-sm text-marigold-300 shadow-lg">
            <Sparkles className="w-4 h-4 text-marigold-400 animate-spin" />
            <span className="font-medium tracking-wide">Beyond Taj Mahal, Jaipur & Goa</span>
            <span className="w-1.5 h-1.5 rounded-full bg-saffron-400" />
            <span className="text-white/80">A Frontend Hackathon Journey</span>
          </div>
        </div>

        {/* Cinematic Headline */}
        <div className="text-center max-w-4xl mx-auto space-y-4">
          <h1 className="font-serif text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white leading-[1.15]">
            India has stories <br className="hidden sm:inline" />
            <span className="text-gradient-saffron underline decoration-marigold-500/40 underline-offset-8">
              you've never heard.
            </span>
          </h1>

          <p className="text-base sm:text-xl text-sandstone-200/90 max-w-2xl mx-auto font-normal leading-relaxed pt-2">
            Step off the beaten path into sacred rock carvings, floating monastic river islands, centuries-old living root bridges, and red granite canyons.
          </p>
        </div>

        {/* Interactive Search Bar */}
        <div className="mt-8 max-w-2xl mx-auto">
          <div className="relative flex items-center bg-white/95 backdrop-blur-md rounded-2xl p-2 shadow-2xl border border-white/30 text-stone-800">
            <div className="pl-3 pr-2 text-saffron-600">
              <Search className="w-5 h-5" />
            </div>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search hidden waterfalls, sacred caves, Ziro Valley, Majuli..."
              className="w-full bg-transparent px-2 py-2 text-sm sm:text-base outline-none text-stone-900 placeholder-stone-500 font-medium"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')}
                className="px-2 text-xs text-stone-400 hover:text-stone-600 font-bold"
              >
                Clear
              </button>
            )}
            <button
              onClick={() => {
                const el = document.getElementById('featured-treasures');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="hidden sm:flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-gradient-to-r from-saffron-600 to-terracotta-600 text-white font-semibold text-sm hover:shadow-lg transition-all"
            >
              <span>Explore</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Quick tags */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-3 text-xs text-sandstone-300">
            <span className="text-stone-400">Popular searches:</span>
            {['Ziro Valley', 'Unakoti', 'Majuli', 'Chettinad', 'Gandikota'].map((tag) => (
              <button
                key={tag}
                onClick={() => setSearchTerm(tag)}
                className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-marigold-200 border border-white/10 transition-colors"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* Flagship Feature Action CTAs */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onStartQuiz}
            className="w-full sm:w-auto flex items-center justify-center gap-2.5 px-8 py-4 rounded-2xl bg-gradient-to-r from-saffron-500 via-marigold-500 to-terracotta-600 text-white font-bold text-base shadow-xl shadow-saffron-600/30 hover:scale-105 active:scale-95 transition-all duration-300"
          >
            <Compass className="w-5 h-5 animate-spin text-sandstone-950" />
            <span>Choose Your Secret Trail</span>
            <span className="bg-white/20 text-xs px-2 py-0.5 rounded-full uppercase">Interactive Quiz</span>
          </button>

          <button
            onClick={onOpenMap}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-4 rounded-2xl bg-white/15 hover:bg-white/25 backdrop-blur-md border border-white/25 text-white font-semibold text-base transition-all duration-200"
          >
            <Map className="w-5 h-5 text-peacock-300" />
            <span>Explore India's Secret Map</span>
          </button>
        </div>

        {/* Subcontinent Real-Time Statistics */}
        <div className="mt-14 pt-8 border-t border-white/15 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div className="p-3">
            <div className="font-serif text-2xl sm:text-3xl font-bold text-marigold-400">
              {totalDestinations}+
            </div>
            <div className="text-xs sm:text-sm text-sandstone-300 mt-1">
              Curated Secret Wonders
            </div>
          </div>
          <div className="p-3">
            <div className="font-serif text-2xl sm:text-3xl font-bold text-white">
              28 States
            </div>
            <div className="text-xs sm:text-sm text-sandstone-300 mt-1">
              Covered with Local Lore
            </div>
          </div>
          <div className="p-3">
            <div className="font-serif text-2xl sm:text-3xl font-bold text-saffron-400">
              5,000+ Yrs
            </div>
            <div className="text-xs sm:text-sm text-sandstone-300 mt-1">
              Living Cultural Heritage
            </div>
          </div>
          <div className="p-3">
            <div className="font-serif text-2xl sm:text-3xl font-bold text-peacock-400">
              0% Crowds
            </div>
            <div className="text-xs sm:text-sm text-sandstone-300 mt-1">
              100% Authentic Discovery
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
