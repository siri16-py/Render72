import React from 'react';
import { Sparkles, Heart, Compass, ShieldCheck } from 'lucide-react';

export const Footer = ({ setActiveTab }) => {
  return (
    <footer className="bg-sandstone-950 text-sandstone-300 pt-16 pb-24 md:pb-16 border-t border-sandstone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 pb-12 border-b border-sandstone-800/80">
          
          {/* Brand Col */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-saffron-600 to-terracotta-600 flex items-center justify-center text-white text-xl">
                🪷
              </div>
              <span className="font-serif text-2xl font-bold text-white tracking-tight">
                Hidden India
              </span>
            </div>
            
            <p className="text-sm text-sandstone-400 max-w-md leading-relaxed">
              An interactive sanctuary celebrating the undocumented corners, sacred stone monoliths, bio-engineered root bridges, and living tribal lore of the Indian subcontinent.
            </p>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-xs text-amber-200/90 leading-relaxed max-w-md">
              <span className="font-bold text-white block mb-0.5">The Responsible Explorer Pledge:</span>
              "Tread softly in sacred groves. Respect indigenous village elders. Leave no plastics behind. Support local artisans directly."
            </div>
          </div>

          {/* Quick Nav */}
          <div>
            <h4 className="font-serif text-white font-bold text-base mb-4">
              Explore Hidden India
            </h4>
            <ul className="space-y-2.5 text-xs text-sandstone-400">
              <li>
                <button 
                  onClick={() => { setActiveTab('discover'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-saffron-400 transition-colors"
                >
                  The Discover Homepage
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActiveTab('stories'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-saffron-400 transition-colors"
                >
                  Stories Beyond Tourism
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActiveTab('map'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-saffron-400 transition-colors"
                >
                  Interactive Subcontinent Map
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActiveTab('trail'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-saffron-400 transition-colors"
                >
                  Choose Your Secret Trail
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActiveTab('journey'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-saffron-400 transition-colors"
                >
                  My Journey & Opinions
                </button>
              </li>
            </ul>
          </div>

          {/* Featured Sanctuaries */}
          <div>
            <h4 className="font-serif text-white font-bold text-base mb-4">
              Featured Sanctuaries
            </h4>
            <ul className="space-y-2.5 text-xs text-sandstone-400">
              <li>Ziro Valley, Arunachal Pradesh</li>
              <li>Unakoti Rock Carvings, Tripura</li>
              <li>Majuli River Island, Assam</li>
              <li>Chettinad Mansions, Tamil Nadu</li>
              <li>Gandikota Canyon, Andhra Pradesh</li>
              <li>Phugtal Cave Gompa, Ladakh</li>
              <li>Living Root Bridges, Meghalaya</li>
            </ul>
          </div>

        </div>

        {/* Bottom Credits */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <div>
            Built with ❤️ for the Frontend Hackathon · Crafted with React & Tailwind CSS
          </div>
          <div className="flex items-center gap-4 text-sandstone-400">
            <span>गुफ़्तगु भारत</span>
            <span>·</span>
            <span>Stories You've Never Heard</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
