export const destinations = [
  // 1. KAILASA MONOLITHIC TEMPLE (ELLORA)
  {
    id: "kailasa-temple",
    name: "Kailasa Monolithic Temple, Ellora",
    state: "Maharashtra",
    region: "East & West",
    category: "Sacred & Mythological",
    type: "sacred",
    tagline: "The world's greatest top-down monolithic wonder carved from a single mountain",
    rating: 5.0,
    visitsCount: 3100,
    heroImage: "https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=1600&q=80",
    image: "https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=1000&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=800&q=80"
    ],
    overview: "Cave 16 at Ellora is not a building assembled with blocks—it is an entire multi-story mountain sculpted top-to-bottom. Over 200,000 tons of solid basalt volcanic rock were scooped out by master stone-cutters without modern cranes or scaffolding, creating a life-sized replica of Mount Kailash.",
    
    // TEMPLE SPECIAL DETAILS: HOW BUILT, DEITY, BHAKTAS
    templeDetails: {
      isTemple: true,
      templeName: "Kailasanatha Temple (Cave 16)",
      howItWasBuilt: "Carved during the 8th century under Rashtrakuta King Krishna I. Unlike ordinary buildings constructed from the foundation upwards, Kailasa was carved vertically downwards from the top of the mountain cliff. Masons dug three deep trenches into the mountain bedrock, isolating a colossal monolith of 200,000 tons of basalt, and then sculpted two-story sanctums, life-sized monolithic elephants, soaring victory pillars (Dhwajasthambhas), and intricate bridge galleries without a single joint.",
      aboutTheDeity: "Dedicated to Lord Shiva as Kailasanatha—the Eternal Ascetic Lord of Mount Kailash. The inner sanctum houses an enormous monolithic Shiva Lingam standing on a grand carved Yoni. Around the temple walls, the masterpiece panel depicts Ravana shaking Mount Kailash with all 20 arms while Goddess Parvati clings to Shiva, who calmly presses down his big toe to effortlessly anchor the entire cosmos.",
      bhaktaStories: [
        {
          devoteeName: "The Rashtrakuta Queen & Master Architect Kokasa",
          title: "The Queen's Fast & The Top-Down Miracle",
          story: "According to the ancient Katha-Kalpataru, the Rashtrakuta King fell mortally ill. His Queen prayed desperately to Lord Shiva, taking a severe vow (Pratigya) of fasting unto death until she could see the Shikhara (spire) of a majestic temple dedicated to Shiva. When the King recovered, architects stated that laying foundations and erecting a temple would take decades—meaning the Queen would perish from starvation. The master craftsman Kokasa stepped forward with divine inspiration: he proposed carving from the mountain summit downwards! Within just seven days, the crowning Shikhara was sculpted and crowned with its golden finial. The Queen beheld the spire, broke her sacred fast, and praised Shiva's mercy."
        },
        {
          devoteeName: "The Stonecutters of the Sahyadri",
          title: "The Zero-Error Basalt Devotion",
          story: "Generations of anonymous stonecutters worked by oil lamp inside suffocating rock dust. If a single chisel blow broke an arm of a deity or cracked a pillar, the entire temple would be ruined forever because stone could not be glued back. Legends hold that the sculptors chanted the Rudram with every chisel stroke, surrendering their mortal egos so that Lord Shiva’s hand guided their iron hammers."
        }
      ]
    },

    // HISTORY
    history: "Commissioned around 756–774 CE by King Krishna I of the Rashtrakuta dynasty. Mughal emperor Aurangzeb later ordered 1,000 soldiers to dismantle the temple in 1682 CE; after three years of continuous sledgehammer blows, they were able to disfigure only a few surface statues, leading Aurangzeb to abandon the attempt in defeat before its indestructible monolithic granite majesty.",
    historyTimeline: [
      { year: "756 CE", event: "Rashtrakuta King Krishna I commissions master architect Kokasa to excavate Cave 16." },
      { year: "780 CE", event: "Top-down excavation of the 100-foot tall vimana completed; covered in brilliant white lime plaster to resemble snowy Mount Kailash." },
      { year: "1682 CE", event: "Aurangzeb's army fails to demolish the monolithic mountain temple after 3 years of attempts." },
      { year: "1983 CE", event: "Inscribed as a UNESCO World Heritage cultural masterpiece." }
    ],
    historyImages: [
      {
        url: "https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=800&q=80",
        caption: "The 100-Foot Monolithic Shikhara Carved Vertically Down from the Cliff"
      },
      {
        url: "https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=800&q=80",
        caption: "Colossal Life-Sized Basalt Elephant & Victory Pillar Carved in Situ"
      }
    ],

    // LEGENDS
    legends: "Elders believe the subterranean cellars underneath the temple hold celestial gateways connecting the physical earth with Kailash, protected by the carved monolithic lions prowling the roofline.",
    legendsDetails: "Acoustic scientists found that chanting Om inside the sanctum produces a continuous 110 Hz resonant vibration that matches the earth's natural geomagnetic frequencies.",
    legendsImages: [
      {
        url: "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=800&q=80",
        caption: "The Dramatic Ravananugraha Panel: Ravana Shaking Mount Kailash"
      }
    ],

    // CLOTHING STYLE & PEOPLE
    clothingStyle: "Traditional Maharashtrian attire: Women wear the iconic 9-yard Nauvari silk saree draped in Kashta style with ancestral pearl Nath (nose ring), green glass bangles, and Kolhapuri Saaj gold necklaces. Men wear pure white cotton Dhotis, Kurta, and the orange or saffron Pheta (turban).",
    clothingImages: [
      {
        url: "https://upload.wikimedia.org/wikipedia/commons/f/fc/Nauvari_Saree.jpg",
        caption: "Maharashtrian woman wearing the authentic 9-yard Nauvari Silk Saree with traditional Kashta drape"
      },
      {
        url: "https://upload.wikimedia.org/wikipedia/commons/f/f9/Warkari_going_to_Wari.jpg",
        caption: "Warkari devotees on the sacred Pandharpur pilgrimage carrying the saffron flag (Bhagva Dhwaj)"
      }
    ],
    peopleDescription: "The local people are deeply spiritual Warkari pilgrims and local stone artisans from the Marathwada region who sing the Abhangs of Sant Tukaram and Sant Dnyaneshwar on festival mornings.",
    peopleImages: [
      {
        url: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=800&q=80",
        caption: "Local woman greeting pilgrims with brass Aarti thali in Verul village"
      }
    ],
    craftsImages: [
      {
        url: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
        caption: "Authentic Paithani handloom sarees woven with pure gold zari threads"
      }
    ],

    architecture: "Dravidian monolithic rock-cut temple with multi-tiered vimana, mandapa, nandi shrine, and two 50-foot freestanding victory pillars.",

    // CUISINE & POPULAR RESTAURANTS
    cuisine: "Authentic Marathwada feast: steaming Pithla Bhakri (gram flour curry with jowar flatbread), fiery Saoji mutton, puran poli with hot clarified ghee, and chilled solkadhi.",
    foodImages: [
      {
        name: "Authentic Pithla Bhakri with Thecha",
        description: "Rustic spiced chickpea flour porridge served with hot woodfire Jowar bhakri and fiery green chili-garlic thecha.",
        url: "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80"
      },
      {
        name: "Festive Puran Poli with Pure Desi Ghee",
        description: "Sweet delicate flatbread stuffed with chana dal, jaggery, cardamom, and nutmeg, bathed in steaming cow ghee.",
        url: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=800&q=80"
      }
    ],
    restaurants: [
      {
        name: "Kailash Restaurant & Thali House",
        type: "Heritage Maharashtrian Thali",
        specialty: "Unlimited Marathwada Thali, Puran Poli, Solkadhi, Kaju Masala",
        location: "Opposite Ellora Caves Gate, Verul",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80"
      },
      {
        name: "Bhoj Thali & Khandeshi Mess",
        type: "Traditional Country Kitchen",
        specialty: "Shev Bhaji, Jowar Bhakri, Bharli Vangi, Mirchi Thecha",
        location: "Khuldabad Bypass, near Aurangabad",
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=800&q=80"
      }
    ],

    bestTimeToVisit: "October to March when winter breezes make walking the stone courtyards pleasant.",
    howToReach: "Fly to Aurangabad (Chhatrapati Sambhajinagar), then a 40-minute drive (30 km) past rural cotton fields to Verul village.",
    secretTip: "Climb the cliffside rim trail above Cave 16 in the morning. Looking down into the 100-foot chasm reveals the top-down chisel patterns etched by master sculptors 1,200 years ago.",
    coordinates: { lat: 20.024, lng: 75.179 },
    mapStateId: "MH",
    trailTags: {
      interests: ["ancient", "sacred"],
      duration: "weekend",
      region: "west",
      vibe: "spiritual"
    }
  },

  // 2. KONARK SUN TEMPLE (ODISHA)
  {
    id: "konark-sun-temple",
    name: "Konark Sun Temple (The Black Pagoda)",
    state: "Odisha",
    region: "East & West",
    category: "Ancient Heritage",
    type: "sacred",
    tagline: "The monumental cosmic chariot of Surya and the heroic sacrifice of Bhakta Dharmapada",
    rating: 4.9,
    visitsCount: 2800,
    heroImage: "https://images.unsplash.com/photo-1600100397608-f010f443b782?auto=format&fit=crop&w=1600&q=80",
    image: "https://images.unsplash.com/photo-1600100397608-f010f443b782?auto=format&fit=crop&w=1000&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1600100397608-f010f443b782?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=800&q=80"
    ],
    overview: "Built on the shores of the Bay of Bengal in 1250 CE, Konark is conceived as the colossal celestial chariot of Surya (the Sun God). Twenty-four carved stone wheels act as precise astronomical sundials, pulled by seven galloping stone horses symbolizing the days of the week.",

    // TEMPLE SPECIAL DETAILS
    templeDetails: {
      isTemple: true,
      templeName: "Arka Kshetra Konark Sun Temple",
      howItWasBuilt: "King Narasimhadeva I of the Eastern Ganga dynasty dedicated 12 years of the kingdom's entire revenue and 1,200 master sculptors led by chief architect Bisu Maharana. The stones were transported along rivers on wooden rafts from distant quarries. Architectural marvel: the crowning cupola contained an enormous magnetic lodestone, and iron plates were clamped inside every stone layer, causing the central green chlorite idol of Surya to hover suspended in mid-air!",
      aboutTheDeity: "Surya Deva, the supreme solar deity who drives away darkness and sickness. Three monumental life-sized sculptures of Surya carved from rare chlorite stone capture the sun at dawn (Prabhat Surya - the Creator), noon (Madhyanna Surya - the Protector), and sunset (Astagachala Surya - the Destroyer).",
      bhaktaStories: [
        {
          devoteeName: "Bhakta Dharmapada (The 12-Year-Old Savior)",
          title: "The Ultimate Sacrifice of Love and Honor",
          story: "For 12 years, chief architect Bisu Maharana and his 1,200 craftsmen labored to complete the soaring temple, but they could not align and mount the massive crowning Kalasha (finial stone) on top of the dome. King Narasimhadeva issued a ruthless royal decree: if the temple was not completed by the next sunrise, all 1,200 craftsmen would be beheaded. That evening, Bisu Maharana's 12-year-old son, Dharmapada—who had never met his father—arrived after studying ancient Shilpa Shastras. Seeing the craftsmen weeping, the child climbed the 200-foot spire in darkness and successfully fixed the heavy crowning stone! However, the craftsmen feared the King would say a 12-year-old child had humiliated 1,200 masters and execute them anyway. To protect his father and the 1,200 artisan families from execution, young Dharmapada bowed to Lord Surya, leaped from the temple spire into the ocean, and offered his soul to the sun."
        },
        {
          devoteeName: "Samba, Son of Lord Krishna",
          title: "The Healing Waters of Chandrabhaga",
          story: "According to the Bhavishya Purana, Krishna's handsome son Samba was afflicted with leprosy due to a curse. Sage Narada advised him to travel to the coastal forest of Maitreya Vana (Konark) to worship Surya. Samba meditated on the sun for 12 years. Pleased with his unwavering Bhakti, Surya cured his leprosy. In gratitude, Samba discovered the first sacred solar idol floating in the Chandrabhaga river and built the first solar shrine."
        }
      ]
    },

    // HISTORY
    history: "Constructed around 1250 CE. European seafaring merchants navigated by its dark stone silhouette on the horizon, calling it the 'Black Pagoda'. The magnetic dome was later dismantled by Portuguese sailors because the magnetic stone disrupted their ship compasses.",
    historyTimeline: [
      { year: "1250 CE", event: "Consecrated by King Narasimhadeva I after defeating invading armies." },
      { year: "1568 CE", event: "Kalapahad invades Odisha, damaging surface sculptures and removing magnetic lodestone." },
      { year: "1903 CE", event: "British lieutenant governor John Woodburn fills the inner hall with sand and stones to prevent roof collapse." },
      { year: "1984 CE", event: "Declared a UNESCO World Heritage Site." }
    ],
    historyImages: [
      {
        url: "https://images.unsplash.com/photo-1600100397608-f010f443b782?auto=format&fit=crop&w=800&q=80",
        caption: "The Astronomical Sundial Wheel: Calculating exact minutes by finger shadows"
      }
    ],

    legends: "The wheels of Konark are not decorative; they are astronomical computers. Each spoke represents a Prahar (3 hours), and beads on the rim calculate time to the exact minute.",
    legendsImages: [
      {
        url: "https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=800&q=80",
        caption: "Nata Mandira: Dance Pavilion where Devadasis danced for Lord Surya"
      }
    ],

    // CLOTHING & PEOPLE
    clothingStyle: "Traditional Odia handlooms: Women drape authentic Sambalpuri Ikat and Bomkai cotton/silk sarees with distinctive temple borders (Kumbha). Odissi dancers wear the classic pleated Sambalpuri silk saree with silver filigree jewellery (Tarakasi) and the sacred crown (Mukuta). Men wear handwoven Sambalpuri Dhotis with Kurta.",
    clothingImages: [
      {
        url: "https://upload.wikimedia.org/wikipedia/commons/2/22/%28A%29_dance_in_saree_by_Sitara_Thobani.jpg",
        caption: "Odissi dancer draped in authentic traditional Sambalpuri silk saree with temple pleats and silver ornaments"
      }
    ],
    peopleDescription: "The resident artisans and fishermen around Konark and Raghurajpur carry a 1,000-year lineage of Pattachitra palm-leaf manuscript painting and stone sculpting.",
    peopleImages: [
      {
        url: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=800&q=80",
        caption: "Raghurajpur Pattachitra master artisan etching sacred epics onto dried palm leaves"
      }
    ],
    craftsImages: [
      {
        url: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
        caption: "Intricate Pattachitra paintings made with natural stone and conch-shell pigments"
      }
    ],

    architecture: "Kalinga architectural style (Pancharatha) with soaring curvilinear Vimana, Natamandira dance pavilion, and 24 monolithic stone chariot wheels.",

    // CUISINE & RESTAURANTS
    cuisine: "Traditional Odia temple delicacies: Dalma (lentils simmered with roasted cumin, pumpkin, and raw papaya), Machha Besara (fish in yellow mustard paste), and the iconic Chhena Poda (sweet baked caramelized cottage cheese).",
    foodImages: [
      {
        name: "Authentic Odia Chhena Poda",
        description: "India's first baked cheesecake: fresh cottage cheese kneaded with cardamom and caramelized sugar, slow-baked inside sal leaves.",
        url: "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=800&q=80"
      },
      {
        name: "Traditional Odia Dalma Feast",
        description: "Nutritious slow-cooked lentils with raw banana, colocasia, grated coconut, and ghee-roasted panch phoron.",
        url: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80"
      }
    ],
    restaurants: [
      {
        name: "OTDC Panthanivas Heritage Dining",
        type: "Authentic Odia Kitchen",
        specialty: "Dalma, Crab Kalia, Chhena Poda, Kanika Sweet Rice",
        location: "Near Konark Temple Main Gate",
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80"
      },
      {
        name: "Chandrabhaga Beach Shack",
        type: "Coastal Seafood Feast",
        specialty: "Fresh Prawn Curry, Pomfret Fry, Steamed Rice with Ghee",
        location: "Chandrabhaga Marine Drive, Konark",
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=800&q=80"
      }
    ],

    bestTimeToVisit: "November to February during the Konark Dance Festival under open winter starlight.",
    howToReach: "Fly to Bhubaneswar (65 km away) and take the scenic 1.5-hour Marine Drive road past casuarina groves.",
    secretTip: "Stand in the center of the wheel shadow at precisely 12 noon on an equinox day to see how the inner axle cast zero shadow.",
    coordinates: { lat: 19.887, lng: 86.094 },
    mapStateId: "OR",
    trailTags: {
      interests: ["ancient", "sacred"],
      duration: "weekend",
      region: "west",
      vibe: "spiritual"
    }
  },

  // 3. CHOPTA & TUNGNATH (UTTARAKHAND)
  {
    id: "chopta-tungnath",
    name: "Chopta & Tungnath Peak",
    state: "Uttarakhand",
    region: "North & Northeast",
    category: "Sacred & Mythological",
    type: "mountains",
    tagline: "The world's highest Shiva shrine at 3,680m where the holy arms of Shiva manifested",
    rating: 4.9,
    visitsCount: 1950,
    heroImage: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1600&q=80",
    image: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1000&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80"
    ],
    overview: "Perched at 3,680 meters (12,073 ft) on the Chandranath mountain in the Garhwal Himalayas, Tungnath is the highest of all five sacred Panch Kedar temples and the highest Shiva temple on earth.",

    // TEMPLE SPECIAL DETAILS
    templeDetails: {
      isTemple: true,
      templeName: "Tungnath Mahadev Shrine",
      howItWasBuilt: "Constructed of weathered dark granite and slate slabs quarried from high Himalayan ridges. The temple has withstood millenniums of severe sub-zero blizzards, freezing glaciers, and avalanches without mortar, stabilized purely by master interlocking gravity masonry.",
      aboutTheDeity: "Lord Shiva worshipped as the Divine Arms (Bahu). Inside the dark stone sanctum, the lingam is an uncarved black rock protruding from the floor resembling the muscular shoulder and arms of a cosmic bull, symbolizing the strength that upholds the universe.",
      bhaktaStories: [
        {
          devoteeName: "The Pandava Brothers of Mahabharata",
          title: "The Search for Redemption & Divine Grace",
          story: "After the Kurukshetra war, the Pandavas were tormented by grief over the death of their kin (Gotra Vadha). Sage Vyasa advised them that only Lord Shiva could forgive them. They journeyed through the Himalayas, but Shiva, displeased by the carnage of war, assumed the form of a bull and hid. When Bhima spotted the bull and tried to catch it, the bull dove into the earth. Its divine body manifested at five holy spots: the hump at Kedarnath, face at Rudranath, hair at Kalpeshwar, navel at Madhyamaheshwar, and his divine arms at Tungnath! The grateful Pandavas constructed shrines at all five locations to thank Shiva for their spiritual liberation."
        },
        {
          devoteeName: "Jagadguru Adi Shankaracharya",
          title: "The Re-Consecration in the Glaciers",
          story: "In the 8th century CE, the young saint Adi Shankaracharya climbed barefoot through Himalayan ice to revive and re-consecrate the ancient shrine. He appointed local Garhwali Maithani Brahmins from the village of Maku to serve as the chief priests, ensuring the ritual worship continued undisturbed across centuries."
        }
      ]
    },

    // HISTORY
    history: "Over 1,000 years old, linked in legend to the Pandavas and preserved by Garhwali mountain communities. During the severe winter months when Tungnath is buried under 10 feet of snow, the idol of Shiva is solemnly brought down in palanquin to Makkumath village.",
    historyTimeline: [
      { year: "Antiquity", event: "Pandava brothers establish the first stone altar on Chandranath mountain." },
      { year: "8th Century CE", event: "Adi Shankaracharya renovates the stone shrine and institutes Maku priestly lineage." },
      { year: "Present Day", event: "Tungnath remains the world's highest active Shaivite temple." }
    ],
    historyImages: [
      {
        url: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=800&q=80",
        caption: "Tungnath Temple standing resolute against snow-covered Garhwal peaks"
      }
    ],

    legends: "Standing 1 km above Tungnath at Chandrashila Peak (4,000m), Lord Rama is believed to have meditated to overcome the affliction of killing Ravana.",
    legendsImages: [
      {
        url: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
        caption: "Chandrashila Moon Rock Summit with panoramic view of Nanda Devi"
      }
    ],

    // CLOTHING STYLE & PEOPLE
    clothingStyle: "Traditional Garhwali Himalayan attire: Women wear the traditional colorful floral Ghagra with matching Dhantu (headscarf), warm woolen jacket, and the iconic large golden nose ring (Nathuli). Men wear warm hand-spun sheep wool coats (Choga) and traditional Pahadi woolen caps.",
    clothingImages: [
      {
        url: "https://upload.wikimedia.org/wikipedia/commons/c/c6/Native_Garhwali_Woman_In_Rishikesh%2C_Uttrakhand.jpg",
        caption: "Native Garhwali woman wearing authentic traditional Pahadi dress with golden Nathuli"
      },
      {
        url: "https://upload.wikimedia.org/wikipedia/commons/3/30/NagTibba-Pahadi_Clothing.jpg",
        caption: "Authentic Himalayan Pahadi hand-spun woolen clothing suited for high mountain passes"
      }
    ],
    peopleDescription: "The resident mountain shepherds and temple priests of Maku village are sturdy, warm-hearted folk who have lived in harmony with high-altitude alpine Bugyals for millenniums.",
    peopleImages: [
      {
        url: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=800&q=80",
        caption: "Garhwali shepherd guiding sheep across the velvet meadows of Chopta Bugyal"
      }
    ],
    craftsImages: [
      {
        url: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
        caption: "Handwoven pure sheep-wool Pankhi blankets and rhododendron petal preserves"
      }
    ],

    architecture: "Ancient stone masonry temple constructed of dark grey granite slabs weathered by centuries of severe Himalayan blizzards.",

    // CUISINE & RESTAURANTS
    cuisine: "Garhwali mountain comfort food: Kafuli (creamy spinach and fenugreek puree cooked in iron kadhais), Chainsoo (toasted black gram gravy), Mandua (finger millet) rotis with hill butter, and Buransh (rhododendron flower) juice.",
    foodImages: [
      {
        name: "Garhwali Kafuli & Mandua Roti",
        description: "Iron-rich wild mountain spinach slow-simmered with buttermilk and rice paste, served with smoky millet flatbread.",
        url: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80"
      },
      {
        name: "Wild Rhododendron (Buransh) Nectar",
        description: "Freshly squeezed juice of wild scarlet rhododendron petals gathered from the Chopta forests in spring.",
        url: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=800&q=80"
      }
    ],
    restaurants: [
      {
        name: "Chopta Meadow Cafe & Dhaba",
        type: "Mountain Trekker Kitchen",
        specialty: "Hot Kafuli, Aloo Paratha, Ginger Lemon Honey Tea, Dal Tadka",
        location: "Chopta Base Meadow",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80"
      },
      {
        name: "Monal Camp Himalayan Kitchen",
        type: "Alpine Woodfire Camp",
        specialty: "Woodfire Kheer, Chainsoo Dal, Fresh Chapatis with Desi Ghee",
        location: "Dugalbitta, near Chopta",
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=800&q=80"
      }
    ],

    bestTimeToVisit: "April to November. In April-May, the forest turns crimson with rhododendron blossoms.",
    howToReach: "Fly to Dehradun (Jolly Grant Airport) or train to Rishikesh, followed by a scenic 7-hour drive along the Alaknanda and Mandakini rivers via Rudraprayag.",
    secretTip: "Continue climbing 1 km beyond Tungnath temple to Chandrashila Peak (4,000 m) at sunrise. You will be greeted with a 360-degree panoramic vista of Nanda Devi, Trishul, and Chaukhamba peaks.",
    coordinates: { lat: 30.488, lng: 79.217 },
    mapStateId: "UT",
    trailTags: {
      interests: ["sacred", "nature"],
      duration: "weekend",
      region: "north",
      vibe: "adventure"
    }
  },

  // 4. ZIRO VALLEY (ARUNACHAL PRADESH)
  {
    id: "ziro-valley",
    name: "Ziro Valley",
    state: "Arunachal Pradesh",
    region: "North & Northeast",
    category: "Nature & Tribal",
    type: "mountains",
    tagline: "The living cultural cradle of the gentle Apatani tribe",
    rating: 4.9,
    visitsCount: 1420,
    heroImage: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1600&q=80",
    image: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1000&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1511497584788-87676104235f?auto=format&fit=crop&w=800&q=80"
    ],
    overview: "Cradled inside pine-clad hills of Lower Subansiri, Ziro Valley is a UNESCO tentative cultural landscape where the indigenous Apatani people have practiced zero-waste sustainable agriculture and intricate forest preservation for centuries.",
    
    history: "Inhabited by the Apatani since ancestral migrations across the Tibetan plateau, the valley remained hidden from the colonial world until British expeditions reached here in 1897. Their agrarian philosophy is celebrated by global anthropologists as one of the world's most sophisticated indigenous land management systems.",
    historyTimeline: [
      { year: "14th Century", event: "Apatani ancestors migrate across the Eastern Himalayas, settling in the secluded Ziro basin." },
      { year: "1897", event: "First recorded British contact; surveyor H.M. Crowe astonished by their wet-rice irrigation canals." },
      { year: "2014", event: "Nominated as a UNESCO World Heritage cultural landscape." }
    ],
    historyImages: [
      {
        url: "https://images.unsplash.com/photo-1511497584788-87676104235f?auto=format&fit=crop&w=800&q=80",
        caption: "The Sacred Bamboo & Blue Pine Groves preserved by Clan Law"
      }
    ],

    legends: "According to tribal oral folklore (Miji chants), the valley was once a vast shimmering lake inhabited by mythical giant amphibians called Buru. The supreme ancestors channeled the water into the Subansiri River, exposing the rich black soil for farming.",
    legendsDetails: "Apatani priests (Nibu) recite epic cosmological hymns that trace the creation of the cosmos from Kujy-Chantü, the primal divine energy. The Sun (Donyi) and Moon (Polo) are revered as omniscient eyes guarding cosmic truth and peace.",
    legendsImages: [
      {
        url: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
        caption: "The Whispering Fog Over the Ancient Buru Lake Bed"
      }
    ],

    // CLOTHING STYLE & PEOPLE
    clothingStyle: "Distinctive Apatani tribal attire: Women wear the handwoven striped 'Gale' skirt wrapped around the waist, paired with large nose plugs (Yaping Hullo) made of cane and distinct dark blue facial tattoos (Tiipe) running from forehead to chin. Men wear woven cotton jackets (Tari) and traditional bamboo cane hats decorated with hornbill beaks.",
    clothingImages: [
      {
        url: "https://upload.wikimedia.org/wikipedia/commons/5/53/Apatani_woman_%28the_tattoo_tribe%29_of_Arunachal_Pradesh%2C_India.jpg",
        caption: "Elder Apatani woman wearing traditional Yaping Hullo nose plugs, facial tattoos, and handwoven Gale skirt"
      }
    ],
    peopleDescription: "The Apatani community is renowned worldwide for its deep warmth, hospitality, and egalitarian clan structure. Elders and youths gather in village Lapangs (open wooden community platforms) to arbitrate local decisions with zero police or court involvement.",
    peopleImages: [
      {
        url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&q=80",
        caption: "Apatani youth wearing traditional handwoven Gale shawl during Myoko festival"
      }
    ],
    craftsImages: [
      {
        url: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
        caption: "Handwoven Gale shawls with organic tribal geometric patterns"
      }
    ],

    architecture: "Traditional raised bamboo stilts homes with mud-packed hearths at the center, insulated against Himalayan frosts.",

    // FOOD & RESTAURANTS
    cuisine: "Pike Pila (fermented bamboo shoot and smoked bacon delicacy), smoky freshwater river fish smoked over hearths, and Apong (fragrant home-brewed red rice wine).",
    foodImages: [
      {
        name: "Pike Pila with Steamed Rice",
        description: "Apatani specialty prepared from fermented bamboo shoots, smoked pork fat, and fresh hill chilies.",
        url: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80"
      },
      {
        name: "Freshly Brewed Apong Wine",
        description: "Fragrant cloudy wine brewed from fermented red rice and mountain herbs served in bamboo tumblers.",
        url: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=800&q=80"
      }
    ],
    restaurants: [
      {
        name: "Kasa Resort & Tribal Kitchen",
        type: "Authentic Apatani Dining",
        specialty: "Bamboo Chicken, Pika Pila, Woodfire Smoked Pork, Apong",
        location: "Hong Village, Ziro",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80"
      }
    ],

    bestTimeToVisit: "March to October (especially September during the outdoor indie music festival or March during Myoko fertility celebrations).",
    howToReach: "Fly to Naharlagun / Guwahati, train to Naharlagun Railway Station, then a scenic 4-hour mountain drive through lush subtropical rain forests.",
    secretTip: "Walk the silent trail between Hong and Hari villages at dawn. The morning mist hanging over the wet bamboo paddy fields sounds like gentle breathing.",
    coordinates: { lat: 27.545, lng: 93.832 },
    mapStateId: "AR",
    trailTags: {
      interests: ["nature", "culture"],
      duration: "week",
      region: "northeast",
      vibe: "peaceful"
    }
  },

  // 5. UNAKOTI (TRIPURA)
  {
    id: "unakoti",
    name: "Unakoti Heritage Site",
    state: "Tripura",
    region: "North & Northeast",
    category: "Ancient Heritage",
    type: "sacred",
    tagline: "The lost hill of 9,999,999 monolithic stone faces",
    rating: 4.8,
    visitsCount: 980,
    heroImage: "https://images.unsplash.com/photo-1596178065887-1198b6148b2b?auto=format&fit=crop&w=1600&q=80",
    image: "https://images.unsplash.com/photo-1596178065887-1198b6148b2b?auto=format&fit=crop&w=1000&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1596178065887-1198b6148b2b?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1472214103451-9374bd1c798e?auto=format&fit=crop&w=800&q=80"
    ],
    overview: "Tucked deep in the subtropical forests of the Raghunandan hills, Unakoti (meaning 'one less than a koti' or 99,99,999 in Bengali) is an awe-inspiring Shaivite pilgrimage site of colossal bas-relief rock carvings dating back to the 7th–9th centuries.",
    
    history: "Carved during the classical Palas and local tribal dynasties, these monumental cliff faces were hidden by thick jungle creepers for centuries before being rediscovered and safeguarded as an ancient sacred open-air gallery.",
    historyTimeline: [
      { year: "7th-9th Century", event: "Master sculptors carve colossal bas-reliefs of Shiva, Durga, and Ganesha into vertical sandstone cliffs." },
      { year: "15th Century", event: "Tripura Manikya dynasty kings patronize the annual Ashokastami mountain bathing pilgrimage." }
    ],
    historyImages: [
      {
        url: "https://images.unsplash.com/photo-1596178065887-1198b6148b2b?auto=format&fit=crop&w=800&q=80",
        caption: "The 30-Foot Central Kal Bhairava Colossus Carved in Sandstone"
      }
    ],

    legends: "Legend says Lord Shiva was traveling to Kashi with one crore (10 million) gods and goddesses. When they stopped here to sleep, Shiva commanded everyone to awake before sunrise. At dawn, only Shiva woke up; in fierce anger at the tardiness of the deities, he cursed all 9,999,999 of them to turn into eternal stone.",
    legendsDetails: "Another folk tale attributes the sculptures to a divine artisan named Kallu Kumhar. He was asked to sculpt one crore images of deities in a single night to accompany Shiva and Parvati to Mount Kailash. By dawn, he was short of exactly one sculpture (Unakoti).",
    legendsImages: [
      {
        url: "https://images.unsplash.com/photo-1472214103451-9374bd1c798e?auto=format&fit=crop&w=800&q=80",
        caption: "The Sacred Waterfall Cascading over Shiva's Crown"
      }
    ],

    // CLOTHING STYLE & PEOPLE
    clothingStyle: "Tripuri and Reang tribal attire: Women wear the 'Rignai' (lower wrap draped from waist to knee) and 'Rikutu' (chest drape), handwoven with vibrant native diamond motifs and paired with heavy silver coin necklaces (Rangbat). Men wear the traditional handwoven Rikutu Gamchha.",
    clothingImages: [
      {
        url: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=80",
        caption: "Tripuri woman dressed in vibrant handwoven Rignai with traditional silver coin ornaments"
      }
    ],
    peopleDescription: "The local Reang and Tripuri hill clans live in bamboo cottages nestled around orange orchards, sharing oral tales of Shiva's passing through their songs.",
    peopleImages: [
      {
        url: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=800&q=80",
        caption: "Local tribal caretaker near the sacred Ashokastami mountain stream"
      }
    ],
    craftsImages: [
      {
        url: "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=800&q=80",
        caption: "Fine Tripura bamboo filigree and sacred temple lamps"
      }
    ],

    architecture: "Gigantic rock-cut bas-reliefs sculpted directly into natural hill escarpments, accompanied by stone carved Nandi bulls and three-eyed Ganeshas.",

    // FOOD & RESTAURANTS
    cuisine: "Tripuri Mui Borok (traditional boiled fish dish made with fermented Berma paste, fresh green chilies, and bamboo shoots) and fragrant local aromatic sticky rice.",
    foodImages: [
      {
        name: "Authentic Tripuri Mui Borok",
        description: "Aromatic fish stew flavored with spicy fermented Berma and hill coriander.",
        url: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80"
      }
    ],
    restaurants: [
      {
        name: "Unakoti Hill View Tourist Lodge",
        type: "Heritage Forest Cafeteria",
        specialty: "Authentic Tripuri Thali, Chakhwi, Fresh Berma Fish Curry",
        location: "Kailashahar Foothills, Tripura",
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80"
      }
    ],

    bestTimeToVisit: "October to April when jungle humidity drops and morning mountain mists envelop the rock statues.",
    howToReach: "Fly to Agartala, take a passenger train to Dharmanagar (140 km), then a short auto-rickshaw or taxi to the hill sanctuary.",
    secretTip: "Stand by the lower mountain stream near the Ganesha rock during late afternoon when sunlight pierces the canopy and illuminates the deity's third eye.",
    coordinates: { lat: 24.321, lng: 92.015 },
    mapStateId: "TR",
    trailTags: {
      interests: ["ancient", "sacred"],
      duration: "weekend",
      region: "northeast",
      vibe: "spiritual"
    }
  },

  // 6. MAJULI RIVER ISLAND (ASSAM)
  {
    id: "majuli",
    name: "Majuli River Island",
    state: "Assam",
    region: "North & Northeast",
    category: "Island & River",
    type: "culture",
    tagline: "The world's largest river island where monks make living masks",
    rating: 4.9,
    visitsCount: 1650,
    heroImage: "https://images.unsplash.com/photo-1626014303757-6466249e0a6d?auto=format&fit=crop&w=1600&q=80",
    image: "https://images.unsplash.com/photo-1518457607834-6e8d80c183c5?auto=format&fit=crop&w=1000&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1626014303757-6466249e0a6d?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1518457607834-6e8d80c183c5?auto=format&fit=crop&w=800&q=80"
    ],
    overview: "Majuli is an enchanting emerald world floating on the mighty Brahmaputra river. It is the spiritual epicenter of Assam's 15th-century Neo-Vaishnavite renaissance, celebrated for its monastic Satras, handmade bamboo masks, and endangered Mishing tribal villages.",
    
    history: "Carved naturally by shifts in the Brahmaputra and Dihing river courses in the 17th century, Majuli became the seat of Saint Srimanta Sankardeva, who preached egalitarian devotion without idol worship or caste divides.",
    historyTimeline: [
      { year: "1449–1568", event: "Saint Srimanta Sankardeva establishes the first Satras (monasteries) on the river island." },
      { year: "1750", event: "A catastrophic flood and earthquake course shifts create the present-day independent river island." }
    ],
    historyImages: [
      {
        url: "https://images.unsplash.com/photo-1518457607834-6e8d80c183c5?auto=format&fit=crop&w=800&q=80",
        caption: "Ancient Namghar Prayer Hall with 500-Year-Old Carved Teak Pillars"
      }
    ],

    legends: "Villagers believe the island is watched over by Garuda (the celestial eagle) and Krishna himself, who is invoked daily through the rhythmic clashing of bronze cymbals and drum beats inside monastic prayer halls.",
    legendsImages: [
      {
        url: "https://images.unsplash.com/photo-1626014303757-6466249e0a6d?auto=format&fit=crop&w=800&q=80",
        caption: "Brahmaputra River Shoreline & Monastic Ferry Crossing at Sunset"
      }
    ],

    // CLOTHING STYLE & PEOPLE
    clothingStyle: "Assamese and Mishing traditional attire: Vaishnavite monks wear pure white cotton Dhoti and Chaddar with sandalwood tilak. Mishing and Assamese women wear the lustrous golden Muga and Eri silk Mekhela Chador (Assam's traditional two-piece saree) woven with intricate red floral motifs (Kingkhap).",
    clothingImages: [
      {
        url: "https://upload.wikimedia.org/wikipedia/commons/b/bb/Assam_Muga_Silk_Mekhela_Chador.jpg",
        caption: "Authentic golden Assam Muga Silk Mekhela Chador handwoven with traditional red motifs"
      }
    ],
    peopleDescription: "The island is home to devoted celibate monks (Bhokots) living in tranquil monastic dormitories, as well as the indigenous Mishing river community whose stilt homes protect them from river surges.",
    peopleImages: [
      {
        url: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=800&q=80",
        caption: "Master Mask Sculptor Hem Chandra Goswami at Natun Samaguri Satra"
      }
    ],
    craftsImages: [
      {
        url: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
        caption: "Intricate Bamboo and Clay Mukha (Drama Masks) of Ten-Headed Ravana"
      }
    ],

    architecture: "Vast Namghars (communal prayer halls) supported by carved wooden pillars, open on all sides to river breezes, and bamboo chang-ghars (elevated tribal stilt cottages).",

    // FOOD & RESTAURANTS
    cuisine: "Traditional Mishing thali with Pitang Oying (vegetables and chicken cooked with crushed rice powder), steamed sticky rice wrapped in aromatic kau leaves, and herbal tea.",
    foodImages: [
      {
        name: "Traditional Mishing Thali Platter",
        description: "Served on fresh banana leaves with smoked pork, bamboo shoot dip, and aromatic Bora Saul sticky rice.",
        url: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80"
      }
    ],
    restaurants: [
      {
        name: "Ural Eco-Kitchen & Cultural Camp",
        type: "Authentic Tribal Stilt Restaurant",
        specialty: "Mishing Thali, Porok Apin (Kau Leaf Rice), Bamboo Shoot Fish",
        location: "Garamur, Majuli",
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80"
      }
    ],

    bestTimeToVisit: "November to March when the Rasotsava festival turns the entire island into a continuous 24-hour celebration of dance, song, and masked theatre.",
    howToReach: "Fly to Jorhat, drive 20 km to Nimati Ghat, and take a 1-hour government wooden motor ferry across the Brahmaputra river to Kamalabari Ghat.",
    secretTip: "Rent a bicycle at Kamalabari and ride along the dykes at sunset. Watch migratory pelicans and river dolphins dipping into the golden waters.",
    coordinates: { lat: 26.953, lng: 94.218 },
    mapStateId: "AS",
    trailTags: {
      interests: ["culture", "ancient"],
      duration: "weekend",
      region: "northeast",
      vibe: "peaceful"
    }
  },

  // 7. CHETTINAD (TAMIL NADU)
  {
    id: "chettinad",
    name: "Chettinad Heritage Mansions",
    state: "Tamil Nadu",
    region: "South",
    category: "Architecture & Crafts",
    type: "heritage",
    tagline: "Palatial 100-room merchant mansions and sun-cured spice trails",
    rating: 4.8,
    visitsCount: 1890,
    heroImage: "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=1600&q=80",
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80"
    ],
    overview: "Chettinad is a cluster of 70+ villages in the dry plains of Tamil Nadu, built by the wealthy seafaring merchant community of Nattukottai Chettiars. It features palatial mansions adorned with Burmese teak, Belgian mirrors, Italian marble, and handmade Athangudi patterned tiles.",
    
    history: "During the 19th and early 20th centuries, Chettiar merchants financed global trade across Burma, Malaya, Ceylon, and Vietnam. They channeled their vast fortunes into building sprawling multi-courtyard ancestral mansions to honor their joint families.",
    historyTimeline: [
      { year: "1850s", event: "Chettiar seafaring merchants establish trade empires across Southeast Asia, shipping teak and marble home." },
      { year: "1912", event: "Construction of the iconic 100-room Kanadukathan Palace featuring egg-white polished lime plaster." }
    ],
    historyImages: [
      {
        url: "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=800&q=80",
        caption: "Grand Inner Courtyard with Burmese Teak Pillars & Belgian Mirrors"
      }
    ],

    legends: "Chettiar weddings traditionally required displaying 1,000 brass and silver vessels across seven concentric inner courtyards. The front verandas were specifically designed to welcome any passing monk or stranger with shade, buttermilk, and clean water.",
    legendsImages: [
      {
        url: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80",
        caption: "The Seven Courtyard Concentric Axis Designed for Rainwater Harvesting"
      }
    ],

    // CLOTHING STYLE & PEOPLE
    clothingStyle: "Traditional Chettinad Tamil attire: Chettiar women wear the heavy, coarse-cotton 'Kandangi' saree or pure South Indian temple silk saree handwoven on pit looms in contrasting earthy tones of mustard yellow, brick red, and ink black. Men wear crisp white Veshti with fine gold borders and folded silk Angavastram.",
    clothingImages: [
      {
        url: "https://upload.wikimedia.org/wikipedia/commons/a/af/South_Silk_Saree.jpg",
        caption: "Tamil woman wearing authentic handwoven South Indian temple silk saree with gold border"
      }
    ],
    peopleDescription: "The Chettiar families take immense pride in their heritage, hospitality, and culinary lineage. Even today, master tile artisans in Athangudi continue hand-pouring molten colored cement with brass stencils passed down across four generations.",
    peopleImages: [
      {
        url: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=800&q=80",
        caption: "Chettinad Aachi (Matriarch) in her ancestral courtyard sharing heirloom recipes"
      }
    ],
    craftsImages: [
      {
        url: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
        caption: "Hand-poured Athangudi patterned geometric terracotta tiles"
      }
    ],

    architecture: "Vast fort-like facades with intricately carved teak lintels displaying Goddess Lakshmi, cooling egg-white plaster walls polished with seashells, and open-to-sky rainwater harvesting courtyards.",

    // FOOD & RESTAURANTS
    cuisine: "Fiery Chettinad pepper chicken, fragrant Kozhukkatta, crispy Seepu Seedai snacks, and coconut-milk laced curries ground fresh on traditional granite stones.",
    foodImages: [
      {
        name: "Authentic Chettinad Pepper Chicken Feast",
        description: "Cooked with 18 freshly roasted spices, stone-ground black tellicherry pepper, shallots, and curry leaves.",
        url: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80"
      }
    ],
    restaurants: [
      {
        name: "The Bangala Heritage Dining Hall",
        type: "World-Famous Heritage Kitchen",
        specialty: "Legendary 7-Course Chettinad Feast, Crab Pepper Masala, Pineapple Rasam",
        location: "Devakottai Road, Karaikudi",
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80"
      }
    ],

    bestTimeToVisit: "October to March when temperatures are mild and evening courtyard breezes cool the ancient brickwork.",
    howToReach: "Fly to Madurai or Tiruchirappalli (Trichy), both roughly 90 km away, and drive through the scenic rural bypass via Karaikudi.",
    secretTip: "Visit an artisan tile workshop in Athangudi village where craftsmen still hand-pour molten colored cement into custom brass stencils with zero electricity.",
    coordinates: { lat: 10.068, lng: 78.784 },
    mapStateId: "TN",
    trailTags: {
      interests: ["culture", "ancient"],
      duration: "weekend",
      region: "south",
      vibe: "culinary"
    }
  },

  // 8. LEPAKSHI VEERABHADRA (ANDHRA PRADESH)
  {
    id: "lepakshi",
    name: "Lepakshi & The Hanging Pillar",
    state: "Andhra Pradesh",
    region: "South",
    category: "Ancient Heritage",
    type: "sacred",
    tagline: "The floating architectural marvel of Vijayanagara stone masters",
    rating: 4.8,
    visitsCount: 1750,
    heroImage: "https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1600&q=80",
    image: "https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1000&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=800&q=80"
    ],
    overview: "Built in 1530 CE by royal brothers Virupanna and Veeranna, the Veerabhadra temple in Lepakshi is a triumph of Vijayanagara stonecraft, celebrated for its defying-gravity hanging pillar, monolithic Nandi, seven-hooded Naga serpent, and ancient ceiling frescoes.",

    // TEMPLE SPECIAL DETAILS
    templeDetails: {
      isTemple: true,
      templeName: "Veerabhadra Swamy Temple",
      howItWasBuilt: "Built atop the tortoise-shaped hillock Kurmasaila. Among its 70 massive carved granite pillars, one famous corner pillar in the Natya Mandapa is completely suspended from the ceiling—it does not touch the ground! British engineer Hamilton tried to dislodge it with a crowbar in the 19th century to understand its secret, but neighboring pillars shifted, proving the entire pavilion is an interconnected harmonic cantilever system.",
      aboutTheDeity: "Lord Veerabhadra, the fierce, protective manifestation of Shiva created to destroy the pride of Daksha. Accompanied by the colossal 15-foot high by 27-foot long monolithic Nandi bull carved from a single granite boulder—the largest monolithic Nandi in India.",
      bhaktaStories: [
        {
          devoteeName: "Bhakta Jatayu (The Divine Eagle)",
          title: "Rise Bird: The Naming of Lepakshi",
          story: "According to the Valmiki Ramayana, when the demon king Ravana abducted Goddess Sita, the noble vulture king Jatayu fought fiercely in mid-air to rescue her. Ravana clipped his wings with his sword Chandrahas. The mortally wounded bird fell onto this hill, clinging to life only to deliver the news to Lord Rama. When Rama found Jatayu breathing his last, he stroked his feathers with divine love and said in Telugu: 'Le, Pakshi!' ('Rise, Bird!'). Rama performed the final rites of Jatayu here, granting him instant Moksha."
        },
        {
          devoteeName: "Royal Treasurer Virupanna",
          title: "The Eyes on the Temple Wall",
          story: "Virupanna, the royal treasurer of King Achyuta Deva Raya, used the state treasury to build this magnificent temple without the King's prior approval. Spies told the King that Virupanna was embezzling royal gold. Enraged, the King ordered Virupanna blinded. Heartbroken that his beloved king doubted his pure devotion to Veerabhadra, Virupanna plucked out his own eyes with his bare hands and hurled them against the sanctum wall! To this day, two red stains remain visible on the western wall of the inner sanctum."
        }
      ]
    },

    history: "Commissioned during the reign of Vijayanagara king Achyuta Deva Raya, preserving the finest surviving ceiling frescoes of medieval South India depicting dancers, warriors, and gods.",
    historyTimeline: [
      { year: "1530 CE", event: "Brothers Virupanna and Veeranna commence construction on Kurmasaila hill." },
      { year: "1538 CE", event: "Monolithic Nandi and Seven-Hooded Nagalinga completed." }
    ],
    historyImages: [
      {
        url: "https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=800&q=80",
        caption: "The Defying-Gravity Hanging Pillar where silk cloths pass underneath"
      }
    ],

    legends: "Behind the sanctum on the natural rock floor lies the giant 'Footprint of Sita' measuring nearly 3 feet in length, from which fresh water continuously trickles irrespective of drought.",
    legendsImages: [
      {
        url: "https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=800&q=80",
        caption: "Colossal Monolithic Nandi Bull carved from a single granite boulder"
      }
    ],

    // CLOTHING STYLE & PEOPLE
    clothingStyle: "Traditional Rayalaseema Telugu attire: Women wear opulent Dharmavaram and Pochampally pure silk sarees with rich brocade pallus, temple gold jewelry (Vaddanam waist belt and Kasu Mala coin necklaces). Men wear pure handloom Dhothi (Pancha) with gold zari border, Lalchi shirt, and Kanduva shawl.",
    clothingImages: [
      {
        url: "https://upload.wikimedia.org/wikipedia/commons/4/4a/PURE_SILK_SAREE.jpg",
        caption: "Devotee draped in authentic Indian pure silk saree with temple pallu"
      }
    ],
    peopleDescription: "The local people in Lepakshi village are warm, traditional weavers and priests whose families have tended the Veerabhadra temple since Vijayanagara times.",
    peopleImages: [
      {
        url: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=800&q=80",
        caption: "Temple priest carrying sacred camphor aarti lamp through the Natya Mandapa"
      }
    ],
    craftsImages: [
      {
        url: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
        caption: "Handmade Lepakshi shadow puppets (Tholu Bommalata) crafted on deer parchment"
      }
    ],

    architecture: "Among its 70 massive granite pillars, one famous corner pillar hangs suspended from the ceiling—never touching the ground. Visitors can pass a silk cloth completely underneath it.",

    // FOOD & RESTAURANTS
    cuisine: "Andhra traditional banana leaf meal with fiery Gongura pickle, Pappu dal with desi ghee, spicy Pesarattu, and sweet jaggery Ariselu.",
    foodImages: [
      {
        name: "Authentic Andhra Banana Leaf Bhojanam",
        description: "Hot steamed Sona Masuri rice served with freshly churned yellow butter, fiery Gongura chutney, and tomato charu.",
        url: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80"
      }
    ],
    restaurants: [
      {
        name: "Haritha Lepakshi Andhra Mess",
        type: "Authentic Andhra Meals",
        specialty: "Unlimited Andhra Bhojanam, Guntur Chicken Kura, Gongura Mutton, Curd Vada",
        location: "Opposite Monolithic Nandi, Lepakshi",
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80"
      }
    ],

    bestTimeToVisit: "October to February during cooler months; mornings are especially serene before midday sun warms the stone floors.",
    howToReach: "Located only 120 km north of Bengaluru International Airport (BLR), making it an easy 2-hour day trip.",
    secretTip: "Look down at the rock floor behind the sanctum to find the giant 'Footprint of Sita' carved into bedrock with a perpetual spring of fresh water seeping from under the heel.",
    coordinates: { lat: 13.804, lng: 77.606 },
    mapStateId: "AP",
    trailTags: {
      interests: ["ancient", "sacred"],
      duration: "day",
      region: "south",
      vibe: "spiritual"
    }
  }
];

export const categories = [
  { id: "all", label: "All Hidden Treasures", icon: "Sparkles", color: "from-amber-500 to-orange-600" },
  { id: "sacred", label: "Sacred Temples & Lore", icon: "Flame", color: "from-orange-500 to-amber-700" },
  { id: "heritage", label: "Ancient Monoliths & Heritage", icon: "Landmark", color: "from-rose-600 to-red-800" },
  { id: "mountains", label: "Mountain Mystics", icon: "Mountain", color: "from-emerald-600 to-teal-800" },
  { id: "nature", label: "Tribal & Hidden Villages", icon: "Trees", color: "from-green-600 to-emerald-700" },
  { id: "landscapes", label: "Mysterious Landscapes", icon: "Compass", color: "from-purple-600 to-indigo-800" }
];

export const regions = [
  { id: "all", label: "All Regions" },
  { id: "North & Northeast", label: "North & Northeast" },
  { id: "South", label: "South India" },
  { id: "East & West", label: "East & West" }
];
