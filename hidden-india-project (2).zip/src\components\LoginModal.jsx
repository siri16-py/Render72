import React, { useState } from 'react';
import { 
  X, 
  User, 
  Mail, 
  Lock, 
  Sparkles, 
  Check, 
  LogOut, 
  ShieldCheck, 
  Compass,
  Star
} from 'lucide-react';
import { playBellChime } from '../utils/audioPlayer';

export const LoginModal = ({ 
  isOpen, 
  onClose, 
  currentUser, 
  onLogin, 
  onLogout,
  visitedCount = 0,
  wishlistCount = 0 
}) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState('🪷');

  if (!isOpen) return null;

  const demoAccounts = [
    {
      name: "Rohan Sharma",
      email: "rohan.explorer@hiddenindia.in",
      badge: "Temple Whisperer 🛕",
      avatar: "🧭"
    },
    {
      name: "Priya Sengupta",
      email: "priya.northeast@hiddenindia.in",
      badge: "Rainforest Pioneer 🌿",
      avatar: "🪷"
    },
    {
      name: "Ananya Iyer",
      email: "ananya.heritage@hiddenindia.in",
      badge: "Living Crafts Connoisseur 🎨",
      avatar: "✨"
    }
  ];

  const handleCustomSubmit = (e) => {
    e.preventDefault();
    if (!email.trim() || (!name.trim() && isSignUp)) return;

    const userObj = {
      name: name.trim() || email.split('@')[0],
      email: email.trim(),
      badge: isSignUp ? "Curious Seeker 🥉" : "Heritage Explorer 🥈",
      avatar: selectedAvatar
    };

    onLogin(userObj);
    playBellChime();
    onClose();
  };

  const handleQuickLogin = (demo) => {
    onLogin(demo);
    playBellChime();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex justify-center p-4 animate-fade-in">
      <div className="relative w-full max-w-md bg-white rounded-3xl overflow-hidden shadow-2xl border border-sandstone-200 my-auto p-6 sm:p-8 space-y-6">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-sandstone-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-saffron-600 to-terracotta-600 text-white flex items-center justify-center text-lg">
              🪷
            </div>
            <div>
              <h3 className="font-serif text-xl font-bold text-stone-900">
                {currentUser ? 'Your Explorer Profile' : (isSignUp ? 'Create Explorer Account' : 'Log In to Hidden India')}
              </h3>
              <p className="text-xs text-stone-500">
                Sync visited places & personal opinions
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-stone-400 hover:text-stone-700 hover:bg-sandstone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* LOGGED IN VIEW */}
        {currentUser ? (
          <div className="space-y-6 text-center">
            <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-saffron-500 to-terracotta-500 text-white font-serif text-3xl font-bold flex items-center justify-center mx-auto shadow-lg ring-4 ring-saffron-100">
              {currentUser.avatar || currentUser.name[0]}
            </div>

            <div>
              <h4 className="font-serif text-2xl font-bold text-stone-900">
                {currentUser.name}
              </h4>
              <p className="text-xs text-stone-500 mt-0.5">{currentUser.email}</p>
              <span className="inline-block mt-2 px-3.5 py-1 rounded-full bg-saffron-100 text-saffron-800 font-bold text-xs">
                {currentUser.badge || 'Explorer'}
              </span>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="p-3.5 rounded-2xl bg-sandstone-50 border border-sandstone-200">
                <span className="text-2xl font-black text-emerald-700 block">{visitedCount}</span>
                <span className="text-xs font-semibold text-stone-600">Visited Places</span>
              </div>
              <div className="p-3.5 rounded-2xl bg-sandstone-50 border border-sandstone-200">
                <span className="text-2xl font-black text-rose-600 block">{wishlistCount}</span>
                <span className="text-xs font-semibold text-stone-600">Wishlist Gems</span>
              </div>
            </div>

            <button
              onClick={() => {
                onLogout();
                onClose();
              }}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl bg-sandstone-100 hover:bg-sandstone-200 text-rose-700 font-bold text-xs transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>Log Out of Account</span>
            </button>
          </div>
        ) : (
          
          /* LOGIN / SIGN UP FORM VIEW */
          <div className="space-y-5">
            {/* 1-Click Demo Profiles (Great for Hackathon judges!) */}
            <div className="p-3.5 rounded-2xl bg-saffron-50/70 border border-saffron-200/80 space-y-2">
              <span className="text-[11px] font-bold text-saffron-900 uppercase tracking-wider block">
                ⚡ 1-Click Instant Demo Login (Hackathon Ready)
              </span>
              <div className="grid grid-cols-3 gap-2">
                {demoAccounts.map((demo, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleQuickLogin(demo)}
                    className="p-2 rounded-xl bg-white hover:bg-saffron-100/60 border border-saffron-200 text-left transition-all text-stone-800 hover:border-saffron-400 group"
                  >
                    <div className="text-lg leading-none mb-1">{demo.avatar}</div>
                    <div className="text-[11px] font-bold truncate group-hover:text-saffron-700">{demo.name.split(' ')[0]}</div>
                    <div className="text-[9px] text-stone-500 truncate">{demo.badge.split(' ')[0]}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="relative flex items-center justify-center">
              <div className="border-t border-sandstone-200 w-full" />
              <span className="bg-white px-3 text-xs text-stone-400 font-medium absolute">or use email</span>
            </div>

            {/* Custom Input Form */}
            <form onSubmit={handleCustomSubmit} className="space-y-3.5">
              {isSignUp && (
                <div>
                  <label className="text-xs font-semibold text-stone-700 block mb-1">Explorer Name</label>
                  <div className="relative flex items-center">
                    <User className="w-4 h-4 text-stone-400 absolute left-3" />
                    <input
                      type="text"
                      required={isSignUp}
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Aarav Sharma"
                      className="w-full pl-9 pr-3 py-2 text-xs bg-sandstone-50 rounded-xl border border-sandstone-300 outline-none focus:border-saffron-500"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="text-xs font-semibold text-stone-700 block mb-1">Email Address</label>
                <div className="relative flex items-center">
                  <Mail className="w-4 h-4 text-stone-400 absolute left-3" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="explorer@hiddenindia.in"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-sandstone-50 rounded-xl border border-sandstone-300 outline-none focus:border-saffron-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-stone-700 block mb-1">Password</label>
                <div className="relative flex items-center">
                  <Lock className="w-4 h-4 text-stone-400 absolute left-3" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-sandstone-50 rounded-xl border border-sandstone-300 outline-none focus:border-saffron-500"
                  />
                </div>
              </div>

              {/* Avatar Selector if Signing Up */}
              {isSignUp && (
                <div>
                  <label className="text-xs font-semibold text-stone-700 block mb-1">Choose Explorer Emblem</label>
                  <div className="flex gap-2">
                    {['🪷', '🧭', '✨', '⛰️', '🦅'].map(emoji => (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => setSelectedAvatar(emoji)}
                        className={`w-9 h-9 rounded-xl border flex items-center justify-center text-base transition-all ${
                          selectedAvatar === emoji
                            ? 'border-saffron-600 bg-saffron-50 scale-110'
                            : 'border-sandstone-200 hover:bg-sandstone-100'
                        }`}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-saffron-600 via-marigold-500 to-terracotta-600 text-white font-bold text-sm shadow hover:shadow-lg transition-all"
              >
                {isSignUp ? 'Create My Account' : 'Log In'}
              </button>
            </form>

            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => setIsSignUp(!isSignUp)}
                className="text-xs text-saffron-700 hover:underline font-semibold"
              >
                {isSignUp ? 'Already have an account? Log In' : "Don't have an account? Sign Up free"}
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
