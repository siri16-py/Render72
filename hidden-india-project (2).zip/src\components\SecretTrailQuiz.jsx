import React, { useState } from 'react';
import { 
  Compass, 
  Sparkles, 
  ArrowRight, 
  ArrowLeft, 
  CheckCircle, 
  RotateCcw, 
  Bookmark, 
  Calendar, 
  MapPin, 
  Sun, 
  Trees, 
  Flame, 
  Landmark, 
  Palette, 
  Globe, 
  Clock, 
  Shirt, 
  ShieldCheck,
  Check
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { quizSteps, trailTemplates } from '../data/quizQuestions';
import { destinations } from '../data/destinations';
import { playBellChime } from '../utils/audioPlayer';

const iconMap = {
  Landmark,
  Flame,
  Trees,
  Palette,
  Sun,
  Calendar,
  Compass,
  Globe,
  MapPin,
  Mountain: Trees,
  SunMedium: Sun
};

export const SecretTrailQuiz = ({ onSelectDestination, onSaveTrail }) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [answers, setAnswers] = useState({
    interest: 'ancient',
    duration: 'weekend',
    region: 'anywhere'
  });
  const [generatedTrail, setGeneratedTrail] = useState(null);
  const [isSaved, setIsSaved] = useState(false);

  const currentStep = quizSteps[currentStepIndex];

  const handleOptionSelect = (optionId) => {
    setAnswers(prev => ({
      ...prev,
      [currentStep.id]: optionId
    }));
  };

  const handleNext = () => {
    if (currentStepIndex < quizSteps.length - 1) {
      setCurrentStepIndex(prev => prev + 1);
    } else {
      generateTrail();
    }
  };

  const handleBack = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(prev => prev - 1);
    }
  };

  const generateTrail = () => {
    playBellChime();
    
    // Fire festive Indian celebration confetti!
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#ea580c', '#f59e0b', '#088395', '#be185d', '#10b981']
    });

    // Lookup trail logic
    let templateKey = `${answers.interest}-${answers.region}`;
    let template = trailTemplates[templateKey];

    if (!template) {
      // Fallback matching logic
      if (answers.region === 'south') {
        template = trailTemplates['ancient-south'];
      } else if (answers.region === 'northeast') {
        template = trailTemplates['culture-northeast'];
      } else if (answers.region === 'west') {
        template = trailTemplates['ancient-west'];
      } else if (answers.interest === 'culture') {
        template = trailTemplates['culture-south'];
      } else if (answers.interest === 'nature') {
        template = trailTemplates['nature-northeast'];
      } else {
        template = trailTemplates['default'];
      }
    }

    // Resolve destinations
    const matchedDests = destinations.filter(d => 
      template.destinations.includes(d.id)
    );

    setGeneratedTrail({
      ...template,
      matchedDestinations: matchedDests.length > 0 ? matchedDests : destinations.slice(0, 2),
      userAnswers: { ...answers }
    });

    setIsSaved(false);
  };

  const handleRestart = () => {
    setGeneratedTrail(null);
    setCurrentStepIndex(0);
    setIsSaved(false);
  };

  const handleSaveToJourney = () => {
    if (onSaveTrail && generatedTrail) {
      onSaveTrail(generatedTrail);
      setIsSaved(true);
      playBellChime();
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-16">
      
      {/* Intro Header */}
      {!generatedTrail && (
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-saffron-100 text-saffron-800 text-xs font-bold uppercase tracking-wider mb-3">
            <Compass className="w-4 h-4 text-saffron-600 animate-spin" />
            <span>Curated Recommendation Engine</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-5xl font-extrabold text-stone-900 tracking-tight">
            Choose Your Secret Trail
          </h2>
          <p className="mt-3 text-sm sm:text-base text-stone-600 leading-relaxed">
            Instead of commercial travel itineraries, answer 3 simple questions to unlock a handcrafted offbeat journey through India's hidden wonders.
          </p>

          {/* Stepper Progress Bar */}
          <div className="mt-8 flex items-center justify-center gap-2">
            {quizSteps.map((step, idx) => (
              <div key={step.id} className="flex items-center">
                <div 
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                    idx === currentStepIndex
                      ? 'bg-saffron-600 text-white shadow-md ring-4 ring-saffron-100'
                      : idx < currentStepIndex
                      ? 'bg-emerald-600 text-white'
                      : 'bg-sandstone-200 text-stone-500'
                  }`}
                >
                  {idx < currentStepIndex ? <Check className="w-4 h-4" /> : idx + 1}
                </div>
                {idx < quizSteps.length - 1 && (
                  <div className={`w-12 sm:w-20 h-1 mx-1.5 rounded-full ${
                    idx < currentStepIndex ? 'bg-emerald-500' : 'bg-sandstone-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* QUIZ STEP CONTAINER */}
      {!generatedTrail ? (
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-sandstone-200 shadow-xl max-w-3xl mx-auto animate-fade-in">
          
          <div className="mb-6">
            <span className="text-xs font-bold text-saffron-700 uppercase tracking-widest block mb-1">
              Step {currentStepIndex + 1} of {quizSteps.length}
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
              {currentStep.title}
            </h3>
            <p className="text-sm text-stone-500 mt-1">
              {currentStep.subtitle}
            </p>
          </div>

          {/* Options Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-6">
            {currentStep.options.map((option) => {
              const Icon = iconMap[option.icon] || Sparkles;
              const isSelected = answers[currentStep.id] === option.id;

              return (
                <div
                  key={option.id}
                  onClick={() => handleOptionSelect(option.id)}
                  className={`p-5 rounded-2xl border-2 cursor-pointer transition-all duration-300 flex flex-col justify-between ${
                    isSelected
                      ? 'border-saffron-600 bg-saffron-50/70 shadow-md scale-[1.02]'
                      : 'border-sandstone-200 hover:border-sandstone-300 bg-sandstone-50/40 hover:bg-white'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className={`p-3 rounded-xl ${
                      isSelected ? 'bg-saffron-600 text-white' : 'bg-sandstone-200 text-stone-700'
                    }`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      isSelected ? 'border-saffron-600 bg-saffron-600 text-white' : 'border-stone-300'
                    }`}>
                      {isSelected && <Check className="w-3 h-3" />}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-bold text-base text-stone-900 leading-snug">
                      {option.label}
                    </h4>
                    <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                      {option.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between pt-6 border-t border-sandstone-100">
            <button
              onClick={handleBack}
              disabled={currentStepIndex === 0}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                currentStepIndex === 0
                  ? 'opacity-30 cursor-not-allowed text-stone-400'
                  : 'text-stone-700 hover:bg-sandstone-100'
              }`}
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>

            <button
              onClick={handleNext}
              className="flex items-center gap-2 px-7 py-3 rounded-xl bg-gradient-to-r from-saffron-600 via-marigold-500 to-terracotta-600 text-white font-bold text-sm shadow-md hover:shadow-xl hover:scale-105 active:scale-95 transition-all"
            >
              <span>{currentStepIndex === quizSteps.length - 1 ? 'Explore My Secret Trail' : 'Continue'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>
      ) : (
        
        /* GENERATED TRAIL RESULT VIEW */
        <div className="space-y-8 animate-fade-in">
          
          {/* Result Banner Card */}
          <div className="bg-gradient-to-br from-sandstone-900 via-stone-900 to-terracotta-950 text-white rounded-3xl p-6 sm:p-10 border border-sandstone-700 shadow-2xl relative overflow-hidden">
            <div className="relative z-10 max-w-3xl space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-saffron-500/20 text-marigold-300 text-xs font-bold uppercase tracking-wider border border-saffron-500/30">
                <Sparkles className="w-3.5 h-3.5 text-marigold-400" />
                <span>Your Personalized Secret Trail</span>
              </div>

              <h3 className="font-serif text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
                {generatedTrail.title}
              </h3>

              <p className="text-base sm:text-lg text-sandstone-200 font-medium">
                {generatedTrail.tagline}
              </p>

              {/* Meta Specs */}
              <div className="flex flex-wrap gap-4 pt-2 text-xs sm:text-sm text-sandstone-300">
                <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-xl backdrop-blur-md">
                  <Calendar className="w-4 h-4 text-marigold-400" />
                  <span>{generatedTrail.durationText}</span>
                </div>
                <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-xl backdrop-blur-md">
                  <Sun className="w-4 h-4 text-saffron-400" />
                  <span>Best Season: {generatedTrail.idealSeason}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 flex flex-wrap gap-3">
                <button
                  onClick={handleSaveToJourney}
                  className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm transition-all ${
                    isSaved
                      ? 'bg-emerald-600 text-white shadow-lg'
                      : 'bg-saffron-600 hover:bg-saffron-500 text-white shadow-md'
                  }`}
                >
                  <Bookmark className="w-4 h-4" />
                  <span>{isSaved ? 'Trail Saved to My Journey!' : 'Save Trail to My Journey'}</span>
                </button>

                <button
                  onClick={handleRestart}
                  className="flex items-center gap-2 px-5 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-sm transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Re-customize Trail</span>
                </button>
              </div>
            </div>
          </div>

          {/* Featured Destinations on this Trail */}
          <div className="space-y-4">
            <h4 className="font-serif text-2xl font-bold text-stone-900 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-saffron-600" />
              <span>Sacred Sanctuaries On Your Route</span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {generatedTrail.matchedDestinations.map((dest) => (
                <div
                  key={dest.id}
                  onClick={() => onSelectDestination(dest)}
                  className="group bg-white rounded-3xl p-5 border border-sandstone-200/90 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="relative aspect-[16/9] rounded-2xl overflow-hidden bg-sandstone-200">
                      <img
                        src={dest.image}
                        alt={dest.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <span className="absolute top-3 left-3 px-3 py-1 rounded-full bg-sandstone-900/80 backdrop-blur-md text-white text-xs font-semibold">
                        {dest.state}
                      </span>
                    </div>

                    <div>
                      <h5 className="font-serif text-xl font-bold text-stone-900 group-hover:text-saffron-600 transition-colors">
                        {dest.name}
                      </h5>
                      <p className="text-xs text-saffron-700 font-semibold mt-0.5">
                        {dest.tagline}
                      </p>
                      <p className="text-xs text-stone-600 mt-2 line-clamp-2">
                        {dest.overview}
                      </p>
                    </div>
                  </div>

                  <div className="pt-3 mt-4 border-t border-sandstone-100 flex items-center justify-between text-xs font-bold text-saffron-600">
                    <span>Read Deep Lore & History</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Day-by-Day Blueprint */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-sandstone-200 shadow-lg space-y-6">
            <h4 className="font-serif text-2xl font-bold text-stone-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-peacock-600" />
              <span>Day-by-Day Secret Journey Blueprint</span>
            </h4>

            <div className="space-y-6">
              {generatedTrail.itinerary.map((item, idx) => (
                <div key={idx} className="p-5 rounded-2xl bg-sandstone-50 border border-sandstone-200 space-y-3">
                  <div className="flex items-center gap-3">
                    <span className="px-3 py-1 rounded-xl bg-saffron-600 text-white font-bold text-xs">
                      {item.day}
                    </span>
                    <h5 className="font-bold text-stone-900 text-base">
                      {item.title}
                    </h5>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 text-xs leading-relaxed text-stone-700">
                    <div className="p-3 rounded-xl bg-white border border-sandstone-200/70">
                      <span className="font-bold text-saffron-700 block mb-1">🌅 Morning Light</span>
                      <p>{item.morning}</p>
                    </div>
                    <div className="p-3 rounded-xl bg-white border border-sandstone-200/70">
                      <span className="font-bold text-amber-700 block mb-1">☀️ Midday Immersion</span>
                      <p>{item.afternoon}</p>
                    </div>
                    <div className="p-3 rounded-xl bg-white border border-sandstone-200/70">
                      <span className="font-bold text-peacock-700 block mb-1">🌙 Evening Stillness</span>
                      <p>{item.evening}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Secret Packing Advice */}
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex items-start gap-3">
              <span className="text-2xl">🎒</span>
              <div>
                <h6 className="font-bold text-amber-900 text-xs sm:text-sm">
                  Secret Explorer Packing Advice
                </h6>
                <p className="text-amber-800 text-xs mt-0.5 leading-relaxed">
                  {generatedTrail.secretPackingTip}
                </p>
              </div>
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
