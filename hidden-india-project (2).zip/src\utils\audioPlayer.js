// Web Audio API ambient generator: Tanpura & Temple Bell Chimes
let audioCtx = null;
let isPlaying = false;
let masterGain = null;
let oscillators = [];
let intervalId = null;

export const initAudio = () => {
  if (!audioCtx) {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    audioCtx = new AudioContext();
  }
};

// Play a resonant Tibetan/Indian singing bowl or temple bell chime
export const playBellChime = () => {
  try {
    initAudio();
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }

    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    // Indian sacred Sa pitch (around 261.6 Hz / C4 or 432 Hz harmonics)
    const baseFreq = 432;
    osc.type = 'sine';
    osc.frequency.setValueAtTime(baseFreq, audioCtx.currentTime);

    gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 3.5);

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    osc.start();
    osc.stop(audioCtx.currentTime + 3.6);
  } catch (e) {
    console.error("Audio error", e);
  }
};

// Toggle calming ambient background meditative soundscape
export const toggleAmbientSound = (onStateChange) => {
  initAudio();
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }

  if (isPlaying) {
    stopAmbientSound();
    if (onStateChange) onStateChange(false);
    return false;
  } else {
    startAmbientSound();
    if (onStateChange) onStateChange(true);
    return true;
  }
};

export const startAmbientSound = () => {
  if (isPlaying) return;
  initAudio();

  masterGain = audioCtx.createGain();
  masterGain.gain.setValueAtTime(0.08, audioCtx.currentTime);
  masterGain.connect(audioCtx.destination);

  // Tanpura drone harmonics (Sa - Pa - Sa' - Sa'') in C# (138.6 Hz, 207.7 Hz, 277.2 Hz)
  const frequencies = [138.59, 207.65, 277.18, 554.37];

  oscillators = frequencies.map((freq, index) => {
    const osc = audioCtx.createOscillator();
    const oscGain = audioCtx.createGain();

    osc.type = index % 2 === 0 ? 'sine' : 'triangle';
    osc.frequency.setValueAtTime(freq, audioCtx.currentTime);

    // Subtle gentle vibrato (LFO)
    const lfo = audioCtx.createOscillator();
    const lfoGain = audioCtx.createGain();
    lfo.frequency.setValueAtTime(0.2 + index * 0.05, audioCtx.currentTime);
    lfoGain.gain.setValueAtTime(1.5, audioCtx.currentTime);
    lfo.connect(osc.frequency);
    lfo.start();

    oscGain.gain.setValueAtTime(0.03 / (index + 1), audioCtx.currentTime);
    osc.connect(oscGain);
    oscGain.connect(masterGain);

    osc.start();
    return { osc, lfo };
  });

  // Occasional gentle temple chime every 14 seconds
  intervalId = setInterval(() => {
    playBellChime();
  }, 14000);

  isPlaying = true;
};

export const stopAmbientSound = () => {
  if (!isPlaying) return;
  if (intervalId) {
    clearInterval(intervalId);
    intervalId = null;
  }
  oscillators.forEach(({ osc, lfo }) => {
    try {
      osc.stop();
      osc.disconnect();
      lfo.stop();
      lfo.disconnect();
    } catch (e) {}
  });
  oscillators = [];
  isPlaying = false;
};
