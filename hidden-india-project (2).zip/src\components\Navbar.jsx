import React, { useState } from 'react';
import { 
  Compass, 
  MapPin, 
  Sparkles, 
  Bookmark, 
  CheckCircle2, 
  User, 
  Volume2, 
  VolumeX, 
  Menu, 
  X,
  Map,
  BookOpen,
  Download
} from 'lucide-react';
import { toggleAmbientSound } from '../utils/audioPlayer';

export const Navbar = ({ 
  activeTab, 
  setActiveTab, 
  currentUser, 
  onOpenAuth, 
  visitedCount, 
  wishlistCount 
}) => {
  const [isAudioActive, setIsAudioActive] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleAudioToggle = () => {
    const newState = toggleAmbientSound(setIsAudioActive);
    setIsAudioActive(newState);
  };

  const navItems = [
    { id: 'discover', label: 'Discover', icon: Sparkles },
    { id: 'stories', label: 'Stories & Lore', icon: BookOpen },
    { id: 'map', label: 'Explore Map', icon: Map },
    { id: 'trail', label: 'Secret Trail', icon: Compass, badge: 'Quiz' },
    { 
      id: 'journey', 
      label: 'My Journey', 
      icon: Bookmark, 
      count: wishlistCount + visitedCount 
    },
  ];

  const handleNavClick = (tabId) => {
    setActiveTab(tabId);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-50 bg-sandstone-50/90 backdrop-blur-md border-b border-sandstone-200/80 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo */}
          <div 
            onClick={() => handleNavClick('discover')}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-saffron-600 via-marigold-500 to-terracotta-600 flex items-center justify-center text-white shadow-md shadow-saffron-500/20 group-hover:scale-105 transition-transform duration-300">
              <span className="text-2xl leading-none">🪷</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-serif text-2xl font-bold tracking-tight text-sandstone-900 group-hover:text-saffron-600 transition-colors">
                  Hidden India
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-saffron-100 text-saffron-800 border border-saffron-200">
                  Offbeat
                </span>
              </div>
              <p className="text-xs text-stone-700 tracking-wide font-medium">
                Stories you've never heard
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1.5 lg:gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`relative flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all duration-200 ${
                    isActive 
                      ? 'bg-gradient-to-r from-saffron-600 to-terracotta-600 text-white shadow-sm shadow-saffron-500/30'
                      : 'text-stone-700 hover:text-stone-900 hover:bg-sandstone-100'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-stone-500'}`} />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full uppercase tracking-wider ${
                      isActive ? 'bg-white/20 text-white' : 'bg-saffron-100 text-saffron-800'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                  {item.count > 0 && (
                    <span className={`text-[11px] font-bold px-1.5 py-0.2 rounded-full min-w-5 text-center ${
                      isActive ? 'bg-white text-saffron-700' : 'bg-saffron-600 text-white'
                    }`}>
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Tools: Audio + User Profile */}
          <div className="flex items-center gap-2.5 sm:gap-3">
            
            {/* Ambient Soundscape Toggle */}
            <button
              onClick={handleAudioToggle}
              title={isAudioActive ? "Mute Tanpura & Temple Bells" : "Play Indian Ambient Soundscape"}
              className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold border transition-all duration-200 ${
                isAudioActive
                  ? 'bg-peacock-600 text-white border-peacock-500 shadow-sm animate-pulse-slow'
                  : 'bg-white text-stone-700 border-sandstone-300 hover:bg-sandstone-100'
              }`}
            >
              {isAudioActive ? (
                <>
                  <Volume2 className="w-4 h-4 text-cyan-200 animate-bounce" />
                  <span className="hidden sm:inline">Vibe ON</span>
                </>
              ) : (
                <>
                  <VolumeX className="w-4 h-4 text-stone-500" />
                  <span className="hidden sm:inline">Ambient Vibe</span>
                </>
              )}
            </button>

            {/* Direct Project ZIP Download Button */}
            <a
              href="/hidden-india-project.zip"
              download="hidden-india-project.zip"
              title="Download Complete Project ZIP"
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-100/80 hover:bg-amber-200/90 text-amber-900 border border-amber-300 text-xs font-bold transition-all shadow-sm"
            >
              <Download className="w-3.5 h-3.5 text-amber-700" />
              <span className="hidden sm:inline">Download ZIP</span>
            </a>

            {/* User Auth Pill */}
            {currentUser ? (
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-xl bg-white border border-sandstone-200 hover:border-saffron-400 hover:shadow-sm transition-all text-left"
              >
                <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-saffron-500 to-terracotta-500 text-white font-bold text-xs flex items-center justify-center shadow-inner">
                  {currentUser.name ? currentUser.name[0].toUpperCase() : 'U'}
                </div>
                <div className="hidden sm:block">
                  <div className="text-xs font-bold text-stone-800 leading-tight">
                    {currentUser.name}
                  </div>
                  <div className="text-[10px] text-saffron-600 font-semibold leading-tight">
                    {currentUser.badge || 'Explorer'}
                  </div>
                </div>
              </button>
            ) : (
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-sandstone-900 hover:bg-sandstone-800 text-white text-xs font-semibold shadow-sm transition-all duration-200"
              >
                <User className="w-3.5 h-3.5 text-marigold-400" />
                <span>Log In</span>
              </button>
            )}

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-xl text-stone-700 hover:bg-sandstone-100 focus:outline-none"
              aria-label="Toggle mobile menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-sandstone-50 border-b border-sandstone-200 px-4 pt-2 pb-6 space-y-2 shadow-lg animate-fade-in">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-base font-semibold transition-all ${
                  isActive 
                    ? 'bg-gradient-to-r from-saffron-600 to-terracotta-600 text-white' 
                    : 'text-stone-700 hover:bg-sandstone-100'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className={`text-xs px-2 py-0.5 rounded-full uppercase font-bold ${
                    isActive ? 'bg-white/20 text-white' : 'bg-saffron-100 text-saffron-800'
                  }`}>
                    {item.badge}
                  </span>
                )}
                {item.count > 0 && (
                  <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${
                    isActive ? 'bg-white text-saffron-700' : 'bg-saffron-600 text-white'
                  }`}>
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* Mobile Bottom Navigation Bar (Persistent touch-friendly mobile bar) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-sandstone-50/95 backdrop-blur-lg border-t border-sandstone-200 px-2 py-2 flex items-center justify-around shadow-2xl">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`relative flex flex-col items-center justify-center p-1.5 rounded-lg transition-all ${
                isActive ? 'text-saffron-700 font-bold' : 'text-stone-500 hover:text-stone-700'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'scale-110 text-saffron-600' : ''}`} />
              <span className="text-[10px] mt-0.5">{item.label}</span>
              {item.count > 0 && (
                <span className="absolute -top-0.5 right-2 w-4 h-4 bg-saffron-600 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                  {item.count}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </header>
  );
};
