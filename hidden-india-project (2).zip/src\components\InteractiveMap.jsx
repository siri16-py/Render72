import React, { useState } from 'react';
import { 
  MapPin, 
  Sparkles, 
  Compass, 
  ArrowRight, 
  BookOpen, 
  Filter, 
  Layers, 
  X,
  CheckCircle2,
  Heart
} from 'lucide-react';
import { indianStates } from '../data/statesData';
import { destinations } from '../data/destinations';
import { playBellChime } from '../utils/audioPlayer';

export const InteractiveMap = ({ 
  onSelectDestination, 
  visitedList = [], 
  wishlist = [],
  onToggleWishlist,
  onToggleVisited 
}) => {
  const [selectedState, setSelectedState] = useState(indianStates[0]); // Default to Arunachal Pradesh
  const [activeRegionFilter, setActiveRegionFilter] = useState('All');
  const [viewMode, setViewMode] = useState('map'); // 'map' or 'grid'

  const regionsList = ['All', 'Northeast', 'South', 'North', 'West', 'Central'];

  const filteredStates = indianStates.filter(st => {
    if (activeRegionFilter === 'All') return true;
    return st.region === activeRegionFilter;
  });

  const handleStateClick = (state) => {
    setSelectedState(state);
    playBellChime();
  };

  // Find linked destination if available
  const linkedDest = selectedState?.destId 
    ? destinations.find(d => d.id === selectedState.destId) 
    : destinations.find(d => d.state.toLowerCase() === selectedState.name.toLowerCase());

  const isStateVisited = linkedDest && visitedList.some(v => v.id === linkedDest.id);
  const isStateWishlisted = linkedDest && wishlist.some(w => w.id === linkedDest.id);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-16">
      
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-saffron-100 text-saffron-800 text-xs font-bold tracking-wide uppercase mb-3">
          <Compass className="w-4 h-4 text-saffron-600 animate-spin" />
          <span>Interactive Subcontinent Atlas</span>
        </div>
        <h2 className="font-serif text-3xl sm:text-5xl font-extrabold text-stone-900 tracking-tight">
          Explore the Secret Map of India
        </h2>
        <p className="mt-3 text-sm sm:text-base text-stone-600 leading-relaxed">
          Click any state or pin across the subcontinent to reveal its hidden sanctuaries, indigenous traditions, and ancient trails.
        </p>

        {/* View Switcher: Map vs Grid */}
        <div className="mt-6 flex items-center justify-center gap-3">
          <div className="inline-flex p-1 rounded-2xl bg-sandstone-200/80 border border-sandstone-300">
            <button
              onClick={() => setViewMode('map')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                viewMode === 'map'
                  ? 'bg-white text-saffron-700 shadow-sm'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Compass className="w-4 h-4" />
              <span>Interactive Map</span>
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                viewMode === 'grid'
                  ? 'bg-white text-saffron-700 shadow-sm'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>State Grid Directory</span>
            </button>
          </div>
        </div>
      </div>

      {/* Region Filter Chips */}
      <div className="flex items-center justify-center gap-2 flex-wrap mb-8">
        {regionsList.map(region => (
          <button
            key={region}
            onClick={() => setActiveRegionFilter(region)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeRegionFilter === region
                ? 'bg-sandstone-900 text-white shadow'
                : 'bg-white text-stone-600 border border-sandstone-200 hover:bg-sandstone-100'
            }`}
          >
            {region} {region !== 'All' ? 'Region' : ''}
          </button>
        ))}
      </div>

      {viewMode === 'map' ? (
        /* MAP VIEW: Interactive SVG layout with Pin-points and Details Drawer */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left/Center: Interactive Map Board */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-4 sm:p-6 border border-sandstone-200 shadow-lg relative overflow-hidden">
            <div className="flex items-center justify-between pb-4 border-b border-sandstone-100 mb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-saffron-700 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Interactive Subcontinent Pins</span>
              </span>
              <span className="text-xs text-stone-500">
                Click a pin to view secrets
              </span>
            </div>

            {/* Custom Interactive India Map Stage */}
            <div className="relative aspect-[4/5] sm:aspect-[1/1] w-full bg-gradient-to-b from-sky-50/70 via-sandstone-50/60 to-emerald-50/50 rounded-2xl border border-sandstone-100 overflow-hidden flex items-center justify-center p-2">
              
              {/* Background Geographic Decorative Watermarks */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
                <span className="font-serif text-6xl sm:text-8xl font-black text-stone-400 select-none tracking-widest">
                  BHARAT
                </span>
              </div>

              {/* Schematic Map Representation with Interactive Points */}
              <svg viewBox="0 0 100 100" className="w-full h-full max-h-[550px] drop-shadow-md">
                {/* Stylized India Subcontinent Outline */}
                <path
                  d="M 33 8 Q 38 6, 42 12 Q 46 16, 50 18 Q 62 20, 72 23 Q 86 25, 93 30 Q 94 36, 88 42 Q 82 46, 78 48 Q 72 50, 68 56 Q 64 64, 52 74 Q 46 82, 42 92 Q 38 84, 34 76 Q 30 68, 28 58 Q 20 54, 18 46 Q 16 38, 24 32 Q 28 22, 33 8 Z"
                  fill="#faf5ee"
                  stroke="#e2d4c0"
                  strokeWidth="0.8"
                  className="transition-colors"
                />

                {/* Subcontinent internal regions dashed accent */}
                <path
                  d="M 28 58 Q 45 55, 68 56"
                  fill="none"
                  stroke="#d5c2a5"
                  strokeWidth="0.5"
                  strokeDasharray="1,1"
                />
                <path
                  d="M 42 12 Q 46 38, 42 92"
                  fill="none"
                  stroke="#d5c2a5"
                  strokeWidth="0.4"
                  strokeDasharray="1,1"
                />

                {/* State Pins */}
                {filteredStates.map((st) => {
                  const isSelected = selectedState?.id === st.id;
                  const isVisited = destinations.some(d => d.mapStateId === st.id && visitedList.some(v => v.id === d.id));

                  return (
                    <g 
                      key={st.id} 
                      onClick={() => handleStateClick(st)}
                      className="cursor-pointer group"
                    >
                      {/* Pulse Ring for selected */}
                      {isSelected && (
                        <circle
                          cx={st.mapCoords.x}
                          cy={st.mapCoords.y}
                          r="4.5"
                          fill="#ea580c"
                          opacity="0.3"
                          className="animate-ping"
                        />
                      )}

                      {/* Pin Outer Circle */}
                      <circle
                        cx={st.mapCoords.x}
                        cy={st.mapCoords.y}
                        r={isSelected ? "3.2" : "2.2"}
                        fill={isSelected ? "#ea580c" : isVisited ? "#059669" : "#088395"}
                        stroke="#ffffff"
                        strokeWidth="0.8"
                        className="transition-all duration-300 group-hover:scale-125"
                      />

                      {/* State Abbreviation Marker */}
                      <text
                        x={st.mapCoords.x}
                        y={st.mapCoords.y - 3}
                        fontSize="2.6"
                        fontWeight="bold"
                        textAnchor="middle"
                        fill={isSelected ? "#ea580c" : "#334155"}
                        className="select-none pointer-events-none font-sans"
                      >
                        {st.name.split(' ')[0]}
                      </text>
                    </g>
                  );
                })}
              </svg>

              {/* Map Legend */}
              <div className="absolute bottom-2 left-2 bg-white/90 backdrop-blur-md p-2.5 rounded-xl border border-sandstone-200 text-[10px] space-y-1 shadow">
                <div className="font-bold text-stone-700">Map Legend</div>
                <div className="flex items-center gap-1.5 text-stone-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-saffron-600" />
                  <span>Selected State</span>
                </div>
                <div className="flex items-center gap-1.5 text-stone-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
                  <span>Visited Gem</span>
                </div>
                <div className="flex items-center gap-1.5 text-stone-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-peacock-600" />
                  <span>Secret Gem Pin</span>
                </div>
              </div>
            </div>

            {/* Quick State Pills below map */}
            <div className="mt-4 flex gap-2 overflow-x-auto pb-2 scrollbar-none">
              {filteredStates.map(st => (
                <button
                  key={st.id}
                  onClick={() => handleStateClick(st)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                    selectedState?.id === st.id
                      ? 'bg-saffron-600 text-white shadow-sm'
                      : 'bg-sandstone-100 hover:bg-sandstone-200 text-stone-700'
                  }`}
                >
                  {st.name}
                </button>
              ))}
            </div>
          </div>

          {/* Right: State Details Preview Card */}
          <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-7 border border-sandstone-200 shadow-xl space-y-5">
            {selectedState ? (
              <>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-widest text-saffron-700 bg-saffron-100 px-3 py-1 rounded-full">
                    {selectedState.region} India
                  </span>
                  <span className="text-xs text-stone-500 font-semibold">
                    Capital: {selectedState.capital}
                  </span>
                </div>

                <div>
                  <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
                    {selectedState.name}
                  </h3>
                  <p className="text-sm font-semibold text-peacock-700 mt-0.5">
                    "{selectedState.badge}"
                  </p>
                </div>

                {/* Destination Image Preview if Linked */}
                {linkedDest && (
                  <div className="relative aspect-[16/9] rounded-2xl overflow-hidden bg-sandstone-200 shadow-md group">
                    <img
                      src={linkedDest.image}
                      alt={linkedDest.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
                    <div className="absolute bottom-3 left-3 text-white">
                      <span className="text-xs font-bold px-2 py-0.5 rounded bg-saffron-600 mr-2">
                        Featured Gem
                      </span>
                      <span className="font-serif font-bold text-base">
                        {linkedDest.name}
                      </span>
                    </div>
                  </div>
                )}

                <p className="text-sm text-stone-700 leading-relaxed">
                  {selectedState.description}
                </p>

                {/* Hidden Treasures List */}
                <div className="space-y-2 pt-2 border-t border-sandstone-100">
                  <span className="text-xs font-bold uppercase tracking-wider text-stone-700 block">
                    Hidden Treasures to Explore:
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {selectedState.destinations.map((dest, i) => (
                      <span
                        key={i}
                        className="px-3 py-1 rounded-xl bg-sandstone-100 text-stone-800 text-xs font-semibold border border-sandstone-200 flex items-center gap-1.5"
                      >
                        <Sparkles className="w-3 h-3 text-marigold-500" />
                        <span>{dest}</span>
                      </span>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-4 flex flex-col sm:flex-row gap-3">
                  {linkedDest && (
                    <button
                      onClick={() => onSelectDestination(linkedDest)}
                      className="flex-1 flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-saffron-600 to-terracotta-600 text-white font-bold text-sm shadow hover:shadow-lg transition-all"
                    >
                      <BookOpen className="w-4 h-4" />
                      <span>Discover {linkedDest.name}</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  )}

                  {linkedDest && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onToggleWishlist(linkedDest)}
                        className={`p-3 rounded-2xl border transition-all ${
                          isStateWishlisted
                            ? 'bg-rose-50 border-rose-300 text-rose-600'
                            : 'bg-white border-sandstone-300 text-stone-600 hover:bg-sandstone-100'
                        }`}
                        title="Save to Wishlist"
                      >
                        <Heart className={`w-5 h-5 ${isStateWishlisted ? 'fill-current' : ''}`} />
                      </button>

                      <button
                        onClick={() => onToggleVisited(linkedDest)}
                        className={`p-3 rounded-2xl border transition-all ${
                          isStateVisited
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-600'
                            : 'bg-white border-sandstone-300 text-stone-600 hover:bg-sandstone-100'
                        }`}
                        title="Mark as Visited"
                      >
                        <CheckCircle2 className="w-5 h-5" />
                      </button>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="text-center py-16 text-stone-500">
                <Compass className="w-10 h-10 mx-auto text-sandstone-300 animate-spin" />
                <p className="mt-3 text-sm">Select any state on the map to inspect its secrets.</p>
              </div>
            )}
          </div>

        </div>
      ) : (
        /* GRID VIEW: All States Directory */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
          {filteredStates.map((st) => {
            const linked = destinations.find(d => d.mapStateId === st.id);
            return (
              <div
                key={st.id}
                onClick={() => {
                  setSelectedState(st);
                  if (linked) onSelectDestination(linked);
                }}
                className="bg-white rounded-3xl p-5 border border-sandstone-200/90 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer hover:-translate-y-1 flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-saffron-700 uppercase tracking-wider bg-saffron-50 px-2.5 py-0.5 rounded-full">
                      {st.region}
                    </span>
                    <span className="text-xs font-semibold text-stone-400">
                      Cap: {st.capital}
                    </span>
                  </div>
                  <h3 className="font-serif text-xl font-bold text-stone-900">
                    {st.name}
                  </h3>
                  <p className="text-xs text-peacock-700 font-semibold mt-0.5">
                    "{st.badge}"
                  </p>
                  <p className="text-xs text-stone-600 mt-2 line-clamp-2 leading-relaxed">
                    {st.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-sandstone-100 flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-700">
                    {st.destinations.length} Secret Sites
                  </span>
                  <span className="text-xs text-saffron-600 font-bold flex items-center gap-1">
                    <span>Explore State</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
