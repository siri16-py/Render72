import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Compass, 
  MapPin, 
  Flame, 
  BookOpen, 
  Heart, 
  CheckCircle2, 
  ArrowRight, 
  Filter, 
  Calendar,
  Layers,
  Award
} from 'lucide-react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { CategoryPills } from './components/CategoryPills';
import { DestinationCard } from './components/DestinationCard';
import { DestinationModal } from './components/DestinationModal';
import { InteractiveMap } from './components/InteractiveMap';
import { SecretTrailQuiz } from './components/SecretTrailQuiz';
import { MyJourney } from './components/MyJourney';
import { WhyHiddenIndia } from './components/WhyHiddenIndia';
import { LoginModal } from './components/LoginModal';
import { Footer } from './components/Footer';
import { destinations, categories, regions } from './data/destinations';
import { playBellChime } from './utils/audioPlayer';

// Sample initial traveler reviews so hackathon judges see vibrant community reviews immediately
const INITIAL_REVIEWS = [
  {
    destinationId: "ziro-valley",
    destinationName: "Ziro Valley",
    author: "Rohan Sharma",
    rating: 5,
    comment: "Walking between Hong and Hari villages at dawn felt like walking into a living dream. The Apatani elders invited us for warm Apong millet wine by their hearth.",
    secretTip: "Borrow a cycle from your homestay and explore the pine groves at 6 AM before anyone else is awake.",
    date: "Oct 12, 2026"
  },
  {
    destinationId: "unakoti",
    destinationName: "Unakoti Heritage Site",
    author: "Ananya Roy",
    rating: 5,
    comment: "The sheer scale of the 30-foot Kal Bhairava rock face carved right in the middle of thick subtropical forest gave me goosebumps. Shiva's legend echoes in every trickle of water.",
    secretTip: "Visit during late afternoon when the slanted sun hits the third eye of Shiva.",
    date: "Sep 28, 2026"
  },
  {
    destinationId: "majuli",
    destinationName: "Majuli River Island",
    author: "Debabrata Das",
    rating: 5,
    comment: "Sitting with Goswami ji at Natun Samaguri Satra as he crafted a Ravana mask from bamboo splits and river clay changed my perspective on traditional Indian art.",
    secretTip: "Catch the wooden ferry at 7:30 AM from Nimati Ghat to watch river dolphins playing in the Brahmaputra.",
    date: "Aug 15, 2026"
  },
  {
    destinationId: "chettinad",
    destinationName: "Chettinad Heritage Mansions",
    author: "Kavitha Raman",
    rating: 5,
    comment: "The 100-room mansions with Burmese teak pillars and Athangudi handmade tiles feel like royal subterranean cathedrals. And the black pepper chicken was unforgettable!",
    secretTip: "Visit the Athangudi tile artisan workshop right in the village where they hand-cast tiles without electricity.",
    date: "Jul 04, 2026"
  }
];

export function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState('discover'); // 'discover', 'stories', 'map', 'trail', 'journey'
  
  // Filtering
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedRegion, setSelectedRegion] = useState('all');

  // Modals & Selected items
  const [selectedDestination, setSelectedDestination] = useState(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Persistent User Data via LocalStorage
  const [currentUser, setCurrentUser] = useState(() => {
    try {
      const saved = localStorage.getItem('hidden_india_user');
      return saved ? JSON.parse(saved) : {
        name: "Aarav Sharma",
        email: "aarav.explorer@hiddenindia.in",
        badge: "Sacred Pathfinder 🥇",
        avatar: "🪷"
      };
    } catch (e) {
      return null;
    }
  });

  const [wishlist, setWishlist] = useState(() => {
    try {
      const saved = localStorage.getItem('hidden_india_wishlist');
      return saved ? JSON.parse(saved) : [destinations[0], destinations[3]]; // Ziro Valley & Chettinad by default
    } catch (e) {
      return [];
    }
  });

  const [visitedList, setVisitedList] = useState(() => {
    try {
      const saved = localStorage.getItem('hidden_india_visited');
      return saved ? JSON.parse(saved) : [destinations[1], destinations[2]]; // Unakoti & Majuli by default
    } catch (e) {
      return [];
    }
  });

  const [userReviews, setUserReviews] = useState(() => {
    try {
      const saved = localStorage.getItem('hidden_india_reviews');
      return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
    } catch (e) {
      return INITIAL_REVIEWS;
    }
  });

  const [savedTrails, setSavedTrails] = useState(() => {
    try {
      const saved = localStorage.getItem('hidden_india_trails');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  // LocalStorage synchronizers
  useEffect(() => {
    try {
      localStorage.setItem('hidden_india_user', JSON.stringify(currentUser));
    } catch (e) {}
  }, [currentUser]);

  useEffect(() => {
    try {
      localStorage.setItem('hidden_india_wishlist', JSON.stringify(wishlist));
    } catch (e) {}
  }, [wishlist]);

  useEffect(() => {
    try {
      localStorage.setItem('hidden_india_visited', JSON.stringify(visitedList));
    } catch (e) {}
  }, [visitedList]);

  useEffect(() => {
    try {
      localStorage.setItem('hidden_india_reviews', JSON.stringify(userReviews));
    } catch (e) {}
  }, [userReviews]);

  useEffect(() => {
    try {
      localStorage.setItem('hidden_india_trails', JSON.stringify(savedTrails));
    } catch (e) {}
  }, [savedTrails]);

  // Wishlist Toggle
  const handleToggleWishlist = (dest) => {
    playBellChime();
    setWishlist(prev => {
      const exists = prev.some(item => item.id === dest.id);
      if (exists) {
        return prev.filter(item => item.id !== dest.id);
      } else {
        return [...prev, dest];
      }
    });
  };

  // Visited Toggle
  const handleToggleVisited = (dest) => {
    playBellChime();
    setVisitedList(prev => {
      const exists = prev.some(item => item.id === dest.id);
      if (exists) {
        return prev.filter(item => item.id !== dest.id);
      } else {
        return [...prev, dest];
      }
    });
  };

  // Add Review / Opinion
  const handleAddReview = (newReview) => {
    setUserReviews(prev => [newReview, ...prev]);
    // Ensure destination is in visited list
    const dest = destinations.find(d => d.id === newReview.destinationId);
    if (dest && !visitedList.some(v => v.id === dest.id)) {
      setVisitedList(prev => [...prev, dest]);
    }
  };

  // Delete Review
  const handleDeleteReview = (index) => {
    setUserReviews(prev => prev.filter((_, i) => i !== index));
  };

  // Save Generated Secret Trail
  const handleSaveTrail = (trail) => {
    setSavedTrails(prev => [trail, ...prev]);
  };

  // Filtered destinations logic
  const filteredDestinations = destinations.filter(dest => {
    const matchesSearch = searchTerm === '' || 
      dest.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dest.state.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dest.tagline.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dest.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dest.overview.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory = selectedCategory === 'all' || 
      dest.type === selectedCategory || 
      dest.category.toLowerCase().includes(selectedCategory.toLowerCase());

    const matchesRegion = selectedRegion === 'all' || dest.region === selectedRegion;

    return matchesSearch && matchesCategory && matchesRegion;
  });

  // Spotlight Gem of the Day
  const spotlightGem = destinations[0]; // Ziro Valley

  return (
    <div className="min-h-screen bg-sandstone-50 flex flex-col font-sans selection:bg-saffron-600 selection:text-white">
      
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        visitedCount={visitedList.length}
        wishlistCount={wishlist.length}
      />

      <main className="flex-1">
        
        {/* VIEW 1: DISCOVER HOMEPAGE */}
        {activeTab === 'discover' && (
          <div>
            {/* Cinematic Hero */}
            <Hero
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              onStartQuiz={() => {
                setActiveTab('trail');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onOpenMap={() => {
                setActiveTab('map');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              totalDestinations={destinations.length}
            />

            {/* Spotlight Gem of the Day Banner */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10 sm:-mt-14 relative z-20">
              <div 
                onClick={() => setSelectedDestination(spotlightGem)}
                className="group bg-white rounded-3xl p-5 sm:p-7 border border-sandstone-200/90 shadow-2xl hover:shadow-saffron-500/10 transition-all duration-300 cursor-pointer overflow-hidden grid grid-cols-1 lg:grid-cols-12 gap-6 items-center"
              >
                <div className="lg:col-span-5 relative aspect-[16/10] rounded-2xl overflow-hidden bg-sandstone-200">
                  <img
                    src={spotlightGem.image}
                    alt={spotlightGem.name}
                    className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-700"
                  />
                  <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-saffron-600 text-white text-xs font-bold uppercase tracking-wider shadow">
                    ✨ Hidden Gem of the Day
                  </div>
                </div>

                <div className="lg:col-span-7 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-saffron-700 uppercase tracking-widest">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>{spotlightGem.state} · {spotlightGem.region}</span>
                  </div>

                  <h3 className="font-serif text-2xl sm:text-3xl font-extrabold text-stone-900 group-hover:text-saffron-600 transition-colors">
                    {spotlightGem.name}
                  </h3>

                  <p className="text-sm font-semibold text-peacock-700">
                    "{spotlightGem.tagline}"
                  </p>

                  <p className="text-xs sm:text-sm text-stone-600 leading-relaxed line-clamp-2">
                    {spotlightGem.overview}
                  </p>

                  <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-sandstone-100">
                    <span className="text-xs text-stone-500 italic">
                      💡 Tip: {spotlightGem.secretTip}
                    </span>

                    <span className="inline-flex items-center gap-1.5 text-xs font-bold text-saffron-600 group-hover:translate-x-1 transition-transform">
                      <span>Uncover Sacred Story</span>
                      <ArrowRight className="w-4 h-4" />
                    </span>
                  </div>
                </div>
              </div>
            </section>

            {/* Filter & Category Exploration Grid */}
            <section id="featured-treasures" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
              
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
                <div>
                  <div className="inline-flex items-center gap-1.5 text-xs font-bold text-saffron-700 uppercase tracking-wider mb-2">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Curated Offbeat Wonders</span>
                  </div>
                  <h2 className="font-serif text-3xl sm:text-4xl font-extrabold text-stone-900 tracking-tight">
                    Explore India Beyond The Crowds
                  </h2>
                </div>

                {/* Region Selector Pills */}
                <div className="flex items-center gap-1.5 bg-sandstone-200/70 p-1 rounded-2xl border border-sandstone-300">
                  {regions.map((reg) => (
                    <button
                      key={reg.id}
                      onClick={() => setSelectedRegion(reg.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                        selectedRegion === reg.id
                          ? 'bg-white text-saffron-700 shadow-sm'
                          : 'text-stone-600 hover:text-stone-900'
                      }`}
                    >
                      {reg.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Category Pills Bar */}
              <div className="mb-8">
                <CategoryPills
                  categories={categories}
                  selectedCategory={selectedCategory}
                  onSelectCategory={setSelectedCategory}
                />
              </div>

              {/* Destination Cards Grid */}
              {filteredDestinations.length === 0 ? (
                <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-sandstone-300 p-8">
                  <p className="font-serif text-xl font-bold text-stone-800">
                    No secret sanctuaries matched your search "{searchTerm}"
                  </p>
                  <p className="text-xs text-stone-500 mt-1">
                    Try searching for waterfalls, Ziro, Majuli, Chettinad, or reset your filters.
                  </p>
                  <button
                    onClick={() => {
                      setSearchTerm('');
                      setSelectedCategory('all');
                      setSelectedRegion('all');
                    }}
                    className="mt-4 px-5 py-2.5 rounded-xl bg-saffron-600 text-white font-bold text-xs"
                  >
                    Reset All Filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {filteredDestinations.map((dest) => (
                    <DestinationCard
                      key={dest.id}
                      destination={dest}
                      onOpenDetails={setSelectedDestination}
                      onToggleWishlist={handleToggleWishlist}
                      onToggleVisited={handleToggleVisited}
                      isWishlisted={wishlist.some(w => w.id === dest.id)}
                      isVisited={visitedList.some(v => v.id === dest.id)}
                    />
                  ))}
                </div>
              )}
            </section>

            {/* Why Hidden India Problem & Solution Section */}
            <WhyHiddenIndia />

            {/* CTA Banner: Choose Your Secret Trail */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
              <div className="bg-gradient-to-r from-saffron-600 via-marigold-500 to-terracotta-700 rounded-3xl p-8 sm:p-14 text-white shadow-2xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-8">
                <div className="space-y-3 max-w-xl">
                  <span className="px-3 py-1 rounded-full bg-white/20 text-xs font-bold uppercase tracking-widest text-amber-100">
                    Interactive Recommendation Quiz
                  </span>
                  <h3 className="font-serif text-3xl sm:text-4xl font-extrabold leading-tight">
                    Not sure where to begin your discovery?
                  </h3>
                  <p className="text-sm sm:text-base text-amber-100 font-medium">
                    Answer 3 quick questions about your curiosity, trip duration, and preferred vibes to unlock your custom secret trail.
                  </p>
                </div>

                <button
                  onClick={() => {
                    setActiveTab('trail');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-8 py-4 rounded-2xl bg-sandstone-950 hover:bg-stone-900 text-white font-bold text-sm sm:text-base shadow-xl hover:scale-105 active:scale-95 transition-all duration-300 flex items-center gap-2 whitespace-nowrap"
                >
                  <Compass className="w-5 h-5 text-marigold-400 animate-spin" />
                  <span>Choose Your Secret Trail</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </section>
          </div>
        )}

        {/* VIEW 2: STORIES BEYOND TOURISM */}
        {activeTab === 'stories' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-16">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-saffron-100 text-saffron-800 text-xs font-bold uppercase tracking-wider mb-3">
                <BookOpen className="w-4 h-4 text-saffron-600" />
                <span>Page 2 — Stories Beyond Tourism</span>
              </div>
              <h2 className="font-serif text-3xl sm:text-5xl font-extrabold text-stone-900 tracking-tight">
                Living Chronicles & Sacred Traditions
              </h2>
              <p className="mt-3 text-sm sm:text-base text-stone-600 leading-relaxed">
                Every destination is more than a photograph: it holds forgotten history, sacred folklore, indigenous artisan crafts, and lost recipes. Click any story to dive into its depth.
              </p>
            </div>

            {/* Stories Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {destinations.map((dest) => (
                <div
                  key={dest.id}
                  onClick={() => setSelectedDestination(dest)}
                  className="group bg-white rounded-3xl overflow-hidden border border-sandstone-200 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col justify-between"
                >
                  <div>
                    <div className="relative aspect-[16/10] overflow-hidden bg-sandstone-200">
                      <img
                        src={dest.image}
                        alt={dest.name}
                        className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-700"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                      <span className="absolute top-3 left-3 px-3 py-1 rounded-full bg-sandstone-900/80 backdrop-blur-md text-white text-xs font-bold">
                        {dest.state}
                      </span>
                      <div className="absolute bottom-3 left-3 right-3 text-white">
                        <span className="text-xs text-amber-200 font-semibold">{dest.category}</span>
                        <h4 className="font-serif font-bold text-xl leading-tight">
                          {dest.name}
                        </h4>
                      </div>
                    </div>

                    <div className="p-5 space-y-3">
                      <p className="text-xs text-saffron-700 font-bold">
                        "{dest.tagline}"
                      </p>
                      <p className="text-xs text-stone-600 line-clamp-3 leading-relaxed">
                        {dest.legends}
                      </p>
                    </div>
                  </div>

                  <div className="p-4 bg-sandstone-50 border-t border-sandstone-100 flex items-center justify-between text-xs font-bold text-saffron-600 group-hover:text-saffron-700">
                    <span className="flex items-center gap-1.5">
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>Read Deep Lore, Architecture & Food</span>
                    </span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* VIEW 3: EXPLORE THE MAP */}
        {activeTab === 'map' && (
          <InteractiveMap
            onSelectDestination={setSelectedDestination}
            visitedList={visitedList}
            wishlist={wishlist}
            onToggleWishlist={handleToggleWishlist}
            onToggleVisited={handleToggleVisited}
          />
        )}

        {/* VIEW 4: CHOOSE YOUR SECRET TRAIL */}
        {activeTab === 'trail' && (
          <SecretTrailQuiz
            onSelectDestination={setSelectedDestination}
            onSaveTrail={handleSaveTrail}
          />
        )}

        {/* VIEW 5: MY JOURNEY & VISITED TRACKER */}
        {activeTab === 'journey' && (
          <MyJourney
            visitedList={visitedList}
            wishlist={wishlist}
            userReviews={userReviews}
            savedTrails={savedTrails}
            onOpenDetails={setSelectedDestination}
            onRemoveWishlist={(id) => setWishlist(prev => prev.filter(item => item.id !== id))}
            onRemoveVisited={(id) => setVisitedList(prev => prev.filter(item => item.id !== id))}
            onAddReview={handleAddReview}
            onDeleteReview={handleDeleteReview}
            currentUser={currentUser}
          />
        )}

      </main>

      {/* Destination Story Deep-Dive Modal */}
      {selectedDestination && (
        <DestinationModal
          destination={selectedDestination}
          onClose={() => setSelectedDestination(null)}
          isWishlisted={wishlist.some(w => w.id === selectedDestination.id)}
          isVisited={visitedList.some(v => v.id === selectedDestination.id)}
          onToggleWishlist={handleToggleWishlist}
          onToggleVisited={handleToggleVisited}
          onAddReview={handleAddReview}
          userReviews={userReviews.filter(r => r.destinationId === selectedDestination.id)}
        />
      )}

      {/* Login & User Profile Modal */}
      <LoginModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={currentUser}
        onLogin={setCurrentUser}
        onLogout={() => setCurrentUser(null)}
        visitedCount={visitedList.length}
        wishlistCount={wishlist.length}
      />

      {/* Footer */}
      <Footer setActiveTab={setActiveTab} />

    </div>
  );
}

export default App;
