import React from 'react';
import { 
  MapPin, 
  Star, 
  Heart, 
  CheckCircle2, 
  ArrowUpRight, 
  Eye, 
  Sparkles,
  BookOpen
} from 'lucide-react';

export const DestinationCard = ({
  destination,
  onOpenDetails,
  onToggleWishlist,
  onToggleVisited,
  isWishlisted,
  isVisited
}) => {
  return (
    <div className="group relative flex flex-col bg-white rounded-3xl overflow-hidden border border-sandstone-200/90 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1.5">
      
      {/* Image Container */}
      <div className="relative aspect-[16/11] overflow-hidden bg-sandstone-200">
        <img
          src={destination.image}
          alt={destination.name}
          loading="lazy"
          className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-700 ease-out"
        />
        
        {/* Dark Vignette Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

        {/* Top Floating Badges */}
        <div className="absolute top-3.5 left-3.5 right-3.5 flex items-center justify-between pointer-events-none">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sandstone-900/85 backdrop-blur-md text-white text-xs font-semibold shadow">
            <MapPin className="w-3.5 h-3.5 text-saffron-400" />
            <span>{destination.state}</span>
          </span>

          {/* Action buttons (pointer-events enabled) */}
          <div className="flex items-center gap-2 pointer-events-auto">
            {/* Visited Checkmark */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleVisited(destination);
              }}
              title={isVisited ? "Marked as Visited" : "Mark as Visited"}
              className={`p-2 rounded-full backdrop-blur-md transition-all duration-200 ${
                isVisited
                  ? 'bg-emerald-600 text-white shadow-md scale-105'
                  : 'bg-white/80 hover:bg-white text-stone-700 hover:text-emerald-600'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
            </button>

            {/* Wishlist Heart */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleWishlist(destination);
              }}
              title={isWishlisted ? "Remove from Saved" : "Save to My Journey"}
              className={`p-2 rounded-full backdrop-blur-md transition-all duration-200 ${
                isWishlisted
                  ? 'bg-rose-500 text-white shadow-md scale-105'
                  : 'bg-white/80 hover:bg-white text-stone-700 hover:text-rose-500'
              }`}
            >
              <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
            </button>
          </div>
        </div>

        {/* Bottom Image Overlay: Region & Category */}
        <div className="absolute bottom-3 left-3.5 right-3.5 flex items-center justify-between text-white text-xs">
          <span className="px-2.5 py-1 rounded-lg bg-white/20 backdrop-blur-md text-amber-200 font-medium">
            {destination.category}
          </span>
          <div className="flex items-center gap-1 bg-black/40 backdrop-blur-md px-2 py-1 rounded-lg">
            <Star className="w-3.5 h-3.5 text-marigold-400 fill-marigold-400" />
            <span className="font-bold">{destination.rating}</span>
          </div>
        </div>
      </div>

      {/* Card Content Body */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        <div>
          <h3 className="font-serif text-xl font-bold text-stone-900 group-hover:text-saffron-600 transition-colors">
            {destination.name}
          </h3>
          <p className="text-xs text-saffron-700 font-semibold mt-0.5">
            {destination.tagline}
          </p>
          <p className="text-sm text-stone-600 line-clamp-2 mt-2 leading-relaxed">
            {destination.overview}
          </p>
        </div>

        {/* Card Footer */}
        <div className="pt-3 border-t border-sandstone-100 flex items-center justify-between">
          <span className="text-xs text-stone-500 font-medium flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-marigold-500" />
            <span>{destination.region}</span>
          </span>

          <button
            onClick={() => onOpenDetails(destination)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-sandstone-100 hover:bg-saffron-600 text-stone-800 hover:text-white font-semibold text-xs transition-all duration-200"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Discover Story</span>
            <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>

      </div>

    </div>
  );
};
