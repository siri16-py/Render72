import React from 'react';
import { 
  Sparkles, 
  Flame, 
  Waves, 
  Mountain, 
  Trees, 
  Landmark, 
  Compass 
} from 'lucide-react';

const iconMap = {
  Sparkles,
  Flame,
  Waves,
  Mountain,
  Trees,
  Landmark,
  Compass
};

export const CategoryPills = ({ categories, selectedCategory, onSelectCategory }) => {
  return (
    <div className="w-full overflow-x-auto pb-2 scrollbar-none">
      <div className="flex items-center gap-2.5 min-w-max px-1">
        {categories.map((cat) => {
          const Icon = iconMap[cat.icon] || Sparkles;
          const isSelected = selectedCategory === cat.id;

          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold transition-all duration-300 border ${
                isSelected
                  ? 'bg-gradient-to-r from-saffron-600 via-marigold-500 to-terracotta-600 text-white border-transparent shadow-md shadow-saffron-600/25 scale-105'
                  : 'bg-white hover:bg-sandstone-100 text-stone-700 border-sandstone-200/80 hover:border-sandstone-300'
              }`}
            >
              <Icon className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-saffron-600'}`} />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
