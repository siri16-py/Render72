import React, { useState } from 'react';
import { 
  X, 
  MapPin, 
  Star, 
  Calendar, 
  Compass, 
  BookOpen, 
  Flame, 
  Palette, 
  Utensils, 
  CheckCircle2, 
  Heart, 
  Share2, 
  Sparkles, 
  Info, 
  MessageSquarePlus, 
  Send, 
  Maximize2, 
  Minimize2, 
  Users, 
  Store, 
  Shirt, 
  Crown,
  Landmark,
  ShieldAlert
} from 'lucide-react';
import { playBellChime } from '../utils/audioPlayer';

export const DestinationModal = ({
  destination,
  onClose,
  isWishlisted,
  isVisited,
  onToggleWishlist,
  onToggleVisited,
  onAddReview,
  userReviews = []
}) => {
  const [activeStoryTab, setActiveStoryTab] = useState(destination.templeDetails ? 'temple' : 'overview');
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isMaximized, setIsMaximized] = useState(true);
  
  // Opinion submission state
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewAuthor, setReviewAuthor] = useState('');
  const [reviewSecretTip, setReviewSecretTip] = useState('');
  const [reviewSuccess, setReviewSuccess] = useState(false);

  if (!destination) return null;

  const galleryImages = [destination.image, ...(destination.gallery || [])];

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    playBellChime();
    alert(`Link for ${destination.name} copied to clipboard!`);
  };

  const handleSubmitReview = (e) => {
    e.preventDefault();
    if (!reviewComment.trim()) return;

    if (onAddReview) {
      onAddReview({
        destinationId: destination.id,
        destinationName: destination.name,
        author: reviewAuthor.trim() || 'Anonymous Explorer',
        rating: reviewRating,
        comment: reviewComment.trim(),
        secretTip: reviewSecretTip.trim(),
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
      });
    }

    if (!isVisited && onToggleVisited) {
      onToggleVisited(destination);
    }

    setReviewSuccess(true);
    setReviewComment('');
    setReviewSecretTip('');
    setTimeout(() => {
      setReviewSuccess(false);
      setShowReviewForm(false);
    }, 2000);
  };

  // Dynamic Tabs based on whether this is an ancient sacred temple or a natural wonder
  const tabs = [
    ...(destination.templeDetails ? [
      { id: 'temple', label: '🛕 Temple, Deity & Bhaktas', icon: Landmark, highlight: true }
    ] : []),
    { id: 'overview', label: 'Overview', icon: BookOpen },
    { id: 'history', label: 'History & Chronicles', icon: Compass },
    { id: 'legends', label: 'Sacred Legends & Lore', icon: Flame },
    { id: 'people', label: 'People & Clothing Style', icon: Users },
    { id: 'cuisine', label: 'Foods & Restaurants', icon: Utensils },
    { id: 'guide', label: 'How to Reach', icon: Info },
    { id: 'reviews', label: 'Opinions', icon: MessageSquarePlus, badge: userReviews.length }
  ];

  return (
    <div className={`fixed inset-0 z-50 overflow-y-auto bg-sandstone-950/90 backdrop-blur-md flex justify-center transition-all duration-300 ${
      isMaximized ? 'p-0' : 'p-2 sm:p-4 md:p-6'
    } animate-fade-in`}>
      
      {/* Modal Dialog Body */}
      <div className={`relative w-full bg-white overflow-hidden shadow-2xl border border-sandstone-200 flex flex-col transition-all duration-300 ${
        isMaximized 
          ? 'h-full min-h-screen rounded-none' 
          : 'max-w-5xl rounded-3xl my-auto max-h-[94vh]'
      }`}>
        
        {/* Hero Banner Header */}
        <div className={`relative w-full overflow-hidden shrink-0 bg-stone-900 transition-all duration-300 ${
          isMaximized ? 'h-72 sm:h-96' : 'h-64 sm:h-80'
        }`}>
          <img
            src={galleryImages[activeImageIndex] || destination.image}
            alt={destination.name}
            className="w-full h-full object-cover transition-all duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/45 to-black/30" />

          {/* Window Control Buttons */}
          <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
            <button
              onClick={() => setIsMaximized(!isMaximized)}
              title={isMaximized ? "Restore Window Size" : "Maximize to Fullscreen"}
              className="p-2.5 rounded-full bg-black/60 hover:bg-black/90 text-white backdrop-blur-md transition-all border border-white/20"
            >
              {isMaximized ? <Minimize2 className="w-5 h-5 text-amber-300" /> : <Maximize2 className="w-5 h-5" />}
            </button>

            <button
              onClick={onClose}
              title="Close Story View"
              className="p-2.5 rounded-full bg-black/60 hover:bg-black/90 text-white backdrop-blur-md transition-all border border-white/20"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Top Location Badges */}
          <div className="absolute top-4 left-4 flex flex-wrap gap-2 z-10">
            <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-saffron-600/90 text-white text-xs font-bold backdrop-blur-md shadow-md">
              <MapPin className="w-3.5 h-3.5 text-amber-200" />
              <span>{destination.state} · {destination.region}</span>
            </span>
            <span className="px-3.5 py-1.5 rounded-full bg-black/60 text-amber-200 text-xs font-bold backdrop-blur-md border border-white/15">
              {destination.category}
            </span>
          </div>

          {/* Bottom Title Bar & Quick Actions */}
          <div className="absolute bottom-4 left-4 right-4 text-white z-10">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
              <div>
                <h2 className="font-serif text-3xl sm:text-5xl font-black tracking-tight leading-tight">
                  {destination.name}
                </h2>
                <p className="text-sm sm:text-base text-amber-200 font-medium mt-1 max-w-2xl">
                  {destination.tagline}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => onToggleWishlist(destination)}
                  className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs font-bold backdrop-blur-md transition-all ${
                    isWishlisted
                      ? 'bg-rose-600 text-white shadow-lg scale-105'
                      : 'bg-white/25 hover:bg-white/35 text-white'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
                  <span>{isWishlisted ? 'Saved' : 'Save'}</span>
                </button>

                <button
                  onClick={() => onToggleVisited(destination)}
                  className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs font-bold backdrop-blur-md transition-all ${
                    isVisited
                      ? 'bg-emerald-600 text-white shadow-lg scale-105'
                      : 'bg-white/25 hover:bg-white/35 text-white'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isVisited ? 'Visited' : 'Mark Visited'}</span>
                </button>

                <button
                  onClick={handleShare}
                  className="p-2.5 rounded-2xl bg-white/25 hover:bg-white/35 text-white backdrop-blur-md transition-all"
                  title="Share this secret story"
                >
                  <Share2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Thumbnail switcher */}
            {galleryImages.length > 1 && (
              <div className="flex gap-2 mt-3.5 overflow-x-auto pb-1 scrollbar-none">
                {galleryImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-14 h-10 rounded-xl overflow-hidden shrink-0 border-2 transition-all ${
                      activeImageIndex === idx ? 'border-saffron-500 scale-105 ring-2 ring-saffron-300' : 'border-white/40 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="Thumbnail" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Tab Navigation Bar */}
        <div className="border-b border-sandstone-200 bg-sandstone-50 px-4 sm:px-8 overflow-x-auto scrollbar-none shrink-0 sticky top-0 z-20 shadow-sm">
          <div className="flex gap-1.5 min-w-max py-2.5">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeStoryTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveStoryTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-saffron-600 to-terracotta-600 text-white shadow-md'
                      : tab.highlight 
                      ? 'bg-amber-100/80 text-amber-900 border border-amber-300 hover:bg-amber-200' 
                      : 'text-stone-700 hover:text-stone-900 hover:bg-sandstone-200/70'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                      isActive ? 'bg-white/20 text-white' : 'bg-saffron-100 text-saffron-800'
                    }`}>
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Scrollable Story Content Area */}
        <div className="p-5 sm:p-8 md:p-10 overflow-y-auto space-y-8 flex-1 text-stone-700">
          
          {/* SPECIAL TAB: TEMPLE, DEITY & BHAKTAS (FOR ANCIENT SACRED TEMPLES) */}
          {activeStoryTab === 'temple' && destination.templeDetails && (
            <div className="space-y-8 animate-fade-in max-w-5xl mx-auto">
              
              {/* Header Box */}
              <div className="p-6 rounded-3xl bg-gradient-to-r from-amber-500/15 via-saffron-500/15 to-orange-500/15 border-2 border-amber-400/60 space-y-3">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-saffron-600 text-white text-xs font-bold uppercase tracking-wider">
                  <Crown className="w-3.5 h-3.5 text-amber-200" />
                  <span>Sacred Temple Architecture & Devotee Lore</span>
                </div>
                <h3 className="font-serif text-3xl sm:text-4xl font-extrabold text-stone-900">
                  {destination.templeDetails.templeName}
                </h3>
              </div>

              {/* 1. HOW IT WAS BUILT */}
              <div className="bg-sandstone-50 p-6 sm:p-8 rounded-3xl border border-sandstone-200 space-y-3">
                <h4 className="font-serif text-2xl font-bold text-stone-900 flex items-center gap-2 text-saffron-800">
                  <Landmark className="w-6 h-6 text-saffron-600" />
                  <span>How The Temple Was Built (Architectural Miracle)</span>
                </h4>
                <p className="text-base sm:text-lg text-stone-700 leading-relaxed pt-1">
                  {destination.templeDetails.howItWasBuilt}
                </p>
              </div>

              {/* 2. ABOUT THE DEITY IN THE TEMPLE */}
              <div className="bg-amber-500/10 p-6 sm:p-8 rounded-3xl border border-amber-400/50 space-y-3">
                <h4 className="font-serif text-2xl font-bold text-amber-950 flex items-center gap-2">
                  <Flame className="w-6 h-6 text-amber-600" />
                  <span>About The Deity in the Temple</span>
                </h4>
                <p className="text-base sm:text-lg text-amber-900 leading-relaxed pt-1">
                  {destination.templeDetails.aboutTheDeity}
                </p>
              </div>

              {/* 3. STORIES OF THE BHAKTAS (DEVOTEES) */}
              <div className="space-y-6">
                <h4 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900 flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-saffron-600" />
                  <span>Inspiring Stories of The Bhaktas (Devotees)</span>
                </h4>
                <p className="text-sm text-stone-600">
                  Sacred legends of devotion, royal vows, and miraculous surrender that moved the divine deity.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-1">
                  {destination.templeDetails.bhaktaStories.map((bhakta, idx) => (
                    <div key={idx} className="bg-white rounded-3xl p-6 border-2 border-sandstone-200 shadow-md hover:shadow-xl transition-all space-y-3 flex flex-col justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="w-8 h-8 rounded-full bg-saffron-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                            {idx + 1}
                          </span>
                          <div>
                            <span className="text-xs font-bold text-saffron-700 uppercase tracking-wider block">
                              {bhakta.devoteeName}
                            </span>
                            <h5 className="font-serif text-xl font-bold text-stone-900">
                              {bhakta.title}
                            </h5>
                          </div>
                        </div>
                        <p className="text-sm text-stone-700 leading-relaxed italic pt-2">
                          "{bhakta.story}"
                        </p>
                      </div>

                      <div className="pt-3 border-t border-sandstone-100 flex items-center justify-between text-xs font-bold text-emerald-800">
                        <span>✨ Miracle of Pure Bhakti</span>
                        <span className="text-stone-400">Oral Legend</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: OVERVIEW */}
          {activeStoryTab === 'overview' && (
            <div className="space-y-8 animate-fade-in max-w-5xl mx-auto">
              <div className="p-6 rounded-3xl bg-gradient-to-r from-saffron-500/10 via-marigold-500/10 to-terracotta-500/10 border border-saffron-200/80">
                <h4 className="font-serif text-2xl font-bold text-saffron-950 mb-3 flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-saffron-600" />
                  <span>The Soul of {destination.name}</span>
                </h4>
                <p className="text-stone-800 text-base sm:text-lg leading-relaxed font-normal">
                  {destination.overview}
                </p>
              </div>

              {/* Secret Tip Highlight */}
              <div className="p-5 rounded-3xl bg-emerald-50 border border-emerald-200 flex items-start gap-4">
                <span className="text-3xl">🤫</span>
                <div>
                  <h5 className="font-bold text-emerald-950 text-base">Insider's Secret Advice</h5>
                  <p className="text-emerald-800 text-sm sm:text-base mt-1 leading-relaxed">
                    {destination.secretTip}
                  </p>
                </div>
              </div>

              {/* Visuals Gallery */}
              <div>
                <h5 className="font-serif text-xl font-bold text-stone-900 mb-4">
                  Visuals of {destination.name}
                </h5>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {galleryImages.map((img, i) => (
                    <div key={i} className="group relative aspect-[16/11] rounded-2xl overflow-hidden bg-sandstone-200 shadow-md">
                      <img 
                        src={img} 
                        alt={`${destination.name} photo ${i+1}`}
                        className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500" 
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: HISTORY & CHRONICLES */}
          {activeStoryTab === 'history' && (
            <div className="space-y-8 animate-fade-in max-w-5xl mx-auto">
              <div>
                <h4 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
                  History, Excavations & Forgotten Eras
                </h4>
                <p className="text-base sm:text-lg text-stone-700 leading-relaxed mt-2">
                  {destination.history}
                </p>
              </div>

              {/* Dedicated History Pictures Gallery */}
              {destination.historyImages && destination.historyImages.length > 0 && (
                <div className="space-y-4">
                  <h5 className="font-bold text-stone-900 text-base uppercase tracking-wider text-saffron-700 flex items-center gap-2">
                    <Compass className="w-4 h-4" />
                    <span>Historical Remains & Ancient Passages</span>
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {destination.historyImages.map((hist, idx) => (
                      <div key={idx} className="bg-sandstone-50 rounded-2xl overflow-hidden border border-sandstone-200 shadow-md group">
                        <div className="relative aspect-[16/10] overflow-hidden bg-sandstone-200">
                          <img
                            src={hist.url}
                            alt={hist.caption}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                        </div>
                        <div className="p-4">
                          <p className="text-sm font-bold text-stone-900">{hist.caption}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Historical Timeline */}
              {destination.historyTimeline && destination.historyTimeline.length > 0 && (
                <div className="bg-sandstone-50 p-6 rounded-3xl border border-sandstone-200 space-y-4">
                  <h5 className="font-serif text-xl font-bold text-stone-900">Historical Timeline</h5>
                  <div className="space-y-4 border-l-2 border-saffron-500 pl-4 ml-2">
                    {destination.historyTimeline.map((item, idx) => (
                      <div key={idx} className="relative">
                        <span className="absolute -left-[23px] top-1 w-3.5 h-3.5 rounded-full bg-saffron-600 ring-4 ring-saffron-100" />
                        <span className="text-xs font-bold text-saffron-700 block uppercase tracking-wider">{item.year}</span>
                        <p className="text-sm text-stone-700 font-medium mt-0.5">{item.event}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: SACRED LEGENDS & LORE */}
          {activeStoryTab === 'legends' && (
            <div className="space-y-8 animate-fade-in max-w-5xl mx-auto">
              <div className="flex items-center gap-2.5 text-saffron-700">
                <Flame className="w-6 h-6" />
                <h4 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
                  Sacred Legends & Oral Folklore
                </h4>
              </div>

              <div className="p-6 rounded-3xl bg-amber-500/10 border border-amber-500/30">
                <p className="text-lg sm:text-xl text-amber-950 leading-relaxed font-serif italic">
                  "{destination.legends}"
                </p>
                {destination.legendsDetails && (
                  <p className="text-sm sm:text-base text-amber-900 mt-4 leading-relaxed font-sans">
                    {destination.legendsDetails}
                  </p>
                )}
              </div>

              {destination.legendsImages && destination.legendsImages.length > 0 && (
                <div className="space-y-4">
                  <h5 className="font-bold text-stone-900 text-base uppercase tracking-wider text-amber-700 flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    <span>Sacred Shrines & Sites of Mythological Wonder</span>
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {destination.legendsImages.map((leg, idx) => (
                      <div key={idx} className="bg-sandstone-50 rounded-2xl overflow-hidden border border-sandstone-200 shadow-md group">
                        <div className="relative aspect-[16/10] overflow-hidden bg-sandstone-200">
                          <img
                            src={leg.url}
                            alt={leg.caption}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                        </div>
                        <div className="p-4">
                          <p className="text-sm font-bold text-stone-900">{leg.caption}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: PEOPLE & TRADITIONAL CLOTHING STYLE */}
          {activeStoryTab === 'people' && (
            <div className="space-y-8 animate-fade-in max-w-5xl mx-auto">
              
              {/* Clothing Style of the People */}
              <div className="bg-saffron-50/70 p-6 sm:p-8 rounded-3xl border border-saffron-200 space-y-4">
                <div className="flex items-center gap-2 text-saffron-800">
                  <Shirt className="w-6 h-6 text-saffron-600" />
                  <h4 className="font-serif text-2xl font-bold text-stone-900">
                    Traditional Clothing Style & Attire of the People
                  </h4>
                </div>
                <p className="text-base sm:text-lg text-stone-700 leading-relaxed">
                  {destination.clothingStyle}
                </p>

                {/* Clothing & Attire Images */}
                {destination.clothingImages && destination.clothingImages.length > 0 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
                    {destination.clothingImages.map((c, idx) => (
                      <div key={idx} className="bg-white rounded-2xl overflow-hidden border border-sandstone-200 shadow-md group">
                        <div className="relative aspect-[4/3] overflow-hidden bg-sandstone-200">
                          <img
                            src={c.url}
                            alt={c.caption}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                        </div>
                        <div className="p-4">
                          <p className="text-sm font-bold text-stone-900">{c.caption}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* People Living In This Place */}
              <div className="space-y-4 pt-4">
                <div className="flex items-center gap-2 text-stone-800">
                  <Users className="w-6 h-6 text-saffron-600" />
                  <h4 className="font-serif text-2xl font-bold text-stone-900">
                    Life & Community of {destination.name}
                  </h4>
                </div>
                <p className="text-base sm:text-lg text-stone-700 leading-relaxed">
                  {destination.peopleDescription || destination.culture}
                </p>

                {/* Pictures of the People Living Here */}
                {destination.peopleImages && destination.peopleImages.length > 0 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
                    {destination.peopleImages.map((p, idx) => (
                      <div key={idx} className="bg-sandstone-50 rounded-2xl overflow-hidden border border-sandstone-200 shadow-md group">
                        <div className="relative aspect-[4/3] overflow-hidden bg-sandstone-200">
                          <img
                            src={p.url}
                            alt={p.caption}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                        </div>
                        <div className="p-4">
                          <p className="text-sm font-bold text-stone-900">{p.caption}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Living Crafts */}
              {destination.craftsImages && destination.craftsImages.length > 0 && (
                <div className="space-y-4 pt-4 border-t border-sandstone-200">
                  <h4 className="font-serif text-xl font-bold text-stone-900 flex items-center gap-2 text-peacock-700">
                    <Palette className="w-5 h-5" />
                    <span>Indigenous Crafts & Artistry</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {destination.craftsImages.map((c, idx) => (
                      <div key={idx} className="bg-sandstone-50 rounded-2xl overflow-hidden border border-sandstone-200 shadow-md group">
                        <div className="relative aspect-[16/10] overflow-hidden bg-sandstone-200">
                          <img
                            src={c.url}
                            alt={c.caption}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                        </div>
                        <div className="p-4">
                          <p className="text-sm font-bold text-stone-900">{c.caption}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          )}

          {/* TAB 6: FOODS & POPULAR RESTAURANTS */}
          {activeStoryTab === 'cuisine' && (
            <div className="space-y-8 animate-fade-in max-w-5xl mx-auto">
              
              <div>
                <div className="flex items-center gap-2 text-terracotta-600 mb-2">
                  <Utensils className="w-6 h-6" />
                  <h4 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
                    Traditional Foods & Lost Flavors
                  </h4>
                </div>
                <p className="text-base sm:text-lg text-stone-700 leading-relaxed">
                  {destination.cuisine}
                </p>
              </div>

              {/* Distinct Food Images */}
              {destination.foodImages && destination.foodImages.length > 0 && (
                <div className="space-y-4">
                  <h5 className="font-bold text-stone-900 text-sm uppercase tracking-wider text-saffron-700">
                    Must-Try Regional Delicacies of {destination.name}
                  </h5>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                    {destination.foodImages.map((food, idx) => (
                      <div key={idx} className="bg-sandstone-50 rounded-2xl overflow-hidden border border-sandstone-200 shadow-md group flex flex-col justify-between">
                        <div>
                          <div className="relative aspect-[16/11] overflow-hidden bg-sandstone-200">
                            <img
                              src={food.url}
                              alt={food.name}
                              className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
                            />
                          </div>
                          <div className="p-4 space-y-1">
                            <h6 className="font-bold text-base text-stone-900">{food.name}</h6>
                            <p className="text-xs text-stone-600 leading-relaxed">{food.description}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Popular Local Restaurants */}
              {destination.restaurants && destination.restaurants.length > 0 && (
                <div className="space-y-4 pt-6 border-t border-sandstone-200">
                  <div className="flex items-center gap-2">
                    <Store className="w-5 h-5 text-saffron-600" />
                    <h5 className="font-serif text-2xl font-bold text-stone-900">
                      Popular Local Restaurants & Authentic Eateries
                    </h5>
                  </div>
                  <p className="text-xs text-stone-500">
                    Hand-picked heritage kitchens and family homestays known for authentic local preparation.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-2">
                    {destination.restaurants.map((rest, idx) => (
                      <div key={idx} className="bg-white rounded-3xl overflow-hidden border border-sandstone-200 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
                        <div>
                          <div className="relative aspect-[16/10] overflow-hidden bg-sandstone-200">
                            <img
                              src={rest.image}
                              alt={rest.name}
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute top-3 right-3 px-2.5 py-1 rounded-lg bg-black/70 backdrop-blur-md text-marigold-300 text-xs font-bold flex items-center gap-1">
                              <Star className="w-3 h-3 fill-marigold-400" />
                              <span>{rest.rating}</span>
                            </div>
                            <span className="absolute bottom-3 left-3 px-3 py-1 rounded-full bg-saffron-600 text-white text-[11px] font-bold">
                              {rest.type}
                            </span>
                          </div>

                          <div className="p-5 space-y-2">
                            <h6 className="font-serif text-lg font-bold text-stone-900 leading-tight">
                              {rest.name}
                            </h6>
                            <p className="text-xs font-semibold text-saffron-700 flex items-center gap-1">
                              <MapPin className="w-3.5 h-3.5" />
                              <span>{rest.location}</span>
                            </p>
                            <div className="pt-2">
                              <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block">Specialties:</span>
                              <p className="text-xs text-stone-700 font-medium mt-0.5">{rest.specialty}</p>
                            </div>
                          </div>
                        </div>

                        <div className="p-4 bg-sandstone-50 border-t border-sandstone-100 flex items-center justify-between text-xs font-bold text-emerald-800">
                          <span>✓ Verified Local Kitchen</span>
                          <span className="text-[11px] text-stone-400">Authentic Recipes</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          )}

          {/* TAB 7: HOW TO REACH */}
          {activeStoryTab === 'guide' && (
            <div className="space-y-6 animate-fade-in max-w-5xl mx-auto">
              <h4 className="font-serif text-2xl font-bold text-stone-900">
                How to Reach Respectfully
              </h4>
              <div className="p-5 rounded-2xl bg-sandstone-100 border border-sandstone-200 space-y-2">
                <h5 className="font-bold text-stone-900 text-sm">Transit Advice:</h5>
                <p className="text-sm text-stone-700 leading-relaxed">
                  {destination.howToReach}
                </p>
              </div>
              <div className="p-5 rounded-2xl bg-peacock-50 border border-peacock-200 space-y-2">
                <h5 className="font-bold text-peacock-900 text-sm">Best Season to Visit:</h5>
                <p className="text-sm text-peacock-800 leading-relaxed">
                  {destination.bestTimeToVisit}
                </p>
              </div>
            </div>
          )}

          {/* TAB 8: REVIEWS & USER OPINIONS */}
          {activeStoryTab === 'reviews' && (
            <div className="space-y-6 animate-fade-in max-w-5xl mx-auto">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-serif text-2xl font-bold text-stone-900">
                    Traveler Opinions & Reflections
                  </h4>
                  <p className="text-xs text-stone-500">
                    Real notes from explorers who journeyed here
                  </p>
                </div>
                <button
                  onClick={() => setShowReviewForm(!showReviewForm)}
                  className="px-4 py-2 rounded-xl bg-saffron-600 hover:bg-saffron-700 text-white font-semibold text-xs transition-colors"
                >
                  {showReviewForm ? 'Cancel' : '+ Write Your Opinion'}
                </button>
              </div>

              {/* Review Submission Form */}
              {showReviewForm && (
                <form onSubmit={handleSubmitReview} className="p-5 rounded-2xl bg-sandstone-100 border border-sandstone-200 space-y-4 animate-fade-in">
                  <h5 className="font-bold text-stone-900 text-sm">Share Your Personal Experience</h5>
                  
                  {reviewSuccess && (
                    <div className="p-3 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-xl flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Thank you! Your opinion has been recorded in your Journey Passport!</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-stone-700 block mb-1">Your Name</label>
                      <input
                        type="text"
                        value={reviewAuthor}
                        onChange={(e) => setReviewAuthor(e.target.value)}
                        placeholder="e.g. Maya Explorer"
                        className="w-full px-3 py-2 text-sm bg-white rounded-xl border border-sandstone-300 outline-none focus:border-saffron-500"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-stone-700 block mb-1">Your Rating</label>
                      <div className="flex items-center gap-1 py-1.5">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            type="button"
                            key={star}
                            onClick={() => setReviewRating(star)}
                            className="p-1 text-marigold-500"
                          >
                            <Star className={`w-5 h-5 ${star <= reviewRating ? 'fill-marigold-500' : 'text-stone-300'}`} />
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-stone-700 block mb-1">What did this place make you feel? (Your Opinion)</label>
                    <textarea
                      rows={3}
                      required
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      placeholder="Describe the atmosphere, local encounters, sacred vibes, or quiet wonders..."
                      className="w-full px-3 py-2 text-sm bg-white rounded-xl border border-sandstone-300 outline-none focus:border-saffron-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-stone-700 block mb-1">Secret Advice for Future Travelers (Optional)</label>
                    <input
                      type="text"
                      value={reviewSecretTip}
                      onChange={(e) => setReviewSecretTip(e.target.value)}
                      placeholder="e.g. Reach before 6:30 AM to hear the morning chants"
                      className="w-full px-3 py-2 text-sm bg-white rounded-xl border border-sandstone-300 outline-none focus:border-saffron-500"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-saffron-600 to-terracotta-600 text-white font-bold text-sm shadow hover:shadow-lg transition-all"
                  >
                    <Send className="w-4 h-4" />
                    <span>Publish Opinion & Mark as Visited</span>
                  </button>
                </form>
              )}

              {/* Opinions List */}
              {userReviews.length === 0 ? (
                <div className="text-center py-8 px-4 rounded-2xl bg-sandstone-50 border border-dashed border-sandstone-300">
                  <p className="text-sm text-stone-500 font-medium">
                    No traveler opinions written yet for {destination.name}.
                  </p>
                  <p className="text-xs text-stone-400 mt-1">
                    Be the first explorer to record your progress and thoughts!
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {userReviews.map((rev, index) => (
                    <div key={index} className="p-4 rounded-2xl bg-sandstone-50 border border-sandstone-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-saffron-600 text-white font-bold text-xs flex items-center justify-center">
                            {rev.author[0]}
                          </div>
                          <div>
                            <span className="font-bold text-xs text-stone-900">{rev.author}</span>
                            <span className="text-[10px] text-stone-400 ml-2">{rev.date}</span>
                          </div>
                        </div>
                        <div className="flex items-center text-marigold-500">
                          {Array.from({ length: rev.rating }).map((_, i) => (
                            <Star key={i} className="w-3.5 h-3.5 fill-marigold-500" />
                          ))}
                        </div>
                      </div>
                      <p className="text-sm text-stone-700 italic">"{rev.comment}"</p>
                      {rev.secretTip && (
                        <div className="text-xs text-emerald-800 bg-emerald-50 p-2 rounded-lg font-medium">
                          💡 Tip: {rev.secretTip}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Modal Bottom Actions */}
        <div className="p-4 bg-sandstone-50 border-t border-sandstone-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-stone-500 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-saffron-600" />
            <span>Hidden India Cultural Preservation Archive</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onToggleWishlist(destination)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                isWishlisted 
                  ? 'bg-rose-100 text-rose-700 border border-rose-300' 
                  : 'bg-white text-stone-700 border border-sandstone-300 hover:bg-sandstone-100'
              }`}
            >
              {isWishlisted ? '❤️ In Your Wishlist' : 'Add to Wishlist'}
            </button>
            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-sandstone-900 hover:bg-sandstone-800 text-white font-bold text-xs transition-colors"
            >
              Close
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
