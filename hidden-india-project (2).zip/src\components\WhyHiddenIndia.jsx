import React from 'react';
import { 
  AlertCircle, 
  Sparkles, 
  Compass, 
  ShieldCheck, 
  HeartHandshake, 
  TreePine, 
  Landmark, 
  Users 
} from 'lucide-react';

export const WhyHiddenIndia = () => {
  return (
    <section className="py-16 lg:py-24 bg-sandstone-100/60 border-y border-sandstone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-saffron-100 text-saffron-800 text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-4 h-4 text-saffron-600" />
            <span>The Hidden India Mission</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-5xl font-extrabold text-stone-900 tracking-tight">
            Why We Built Hidden India
          </h2>
          <p className="mt-3 text-sm sm:text-base text-stone-600 leading-relaxed">
            Mainstream tourism drives millions to the same three crowded circuits, leaving India's deepest cultural treasures, sacred rock faces, and ancient artisan villages in the shadows.
          </p>
        </div>

        {/* Comparison: The Problem vs Our Solution */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
          
          {/* THE PROBLEM CARD */}
          <div className="bg-white rounded-3xl p-7 sm:p-9 border border-rose-200 shadow-sm space-y-6 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold uppercase tracking-wider">
                <AlertCircle className="w-4 h-4 text-rose-600" />
                <span>The Problem With Commercial Tourism</span>
              </div>
              <h3 className="font-serif text-2xl font-bold text-stone-900">
                Overcrowded circuits & forgotten heritage
              </h3>
              <p className="text-sm text-stone-600 leading-relaxed">
                Travel search engines repeat the same top 10 commercial hotspots. Meanwhile:
              </p>

              <ul className="space-y-3.5 pt-2">
                {[
                  "Lesser-known 1,000-year-old heritage sites receive zero attention or economic support.",
                  "Centuries-old tribal crafts, living mask-makers, and oral folklore are slowly dying unnoticed.",
                  "Curious travellers struggle to find organized, respectful, and reliable info on offbeat gems.",
                  "Overtourism degrades fragile ecosystems in Goa, Manali, and Jaipur while authentic sanctuaries remain untouched."
                ].map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-sm text-stone-700">
                    <span className="w-5 h-5 rounded-full bg-rose-50 text-rose-600 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                      ✕
                    </span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-2xl bg-rose-50/60 border border-rose-200/60 text-xs text-rose-900 font-medium">
              Over 85% of foreign & domestic tourism is concentrated in just 5 states.
            </div>
          </div>

          {/* OUR SOLUTION CARD */}
          <div className="bg-gradient-to-br from-sandstone-900 to-stone-950 text-white rounded-3xl p-7 sm:p-9 border border-sandstone-700 shadow-xl space-y-6 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-saffron-500/20 text-marigold-300 text-xs font-bold uppercase tracking-wider border border-saffron-500/30">
                <Sparkles className="w-4 h-4 text-marigold-400" />
                <span>The Hidden India Solution</span>
              </div>
              <h3 className="font-serif text-2xl font-bold text-white">
                One vibrant platform for the real India
              </h3>
              <p className="text-sm text-sandstone-300 leading-relaxed">
                We celebrate the soul of India through interactive storytelling, ethical exploration, and community memory keeping:
              </p>

              <ul className="space-y-3.5 pt-2">
                {[
                  "Stories Beyond Tourism: Dedicated archives of history, mythology, architecture, recipes, and etiquette.",
                  "Interactive Subcontinent Atlas: Geo-tagged secret pins across all 28 states and territories.",
                  "Choose Your Secret Trail: A dynamic recommendation engine based on personal curiosity, not commercial ads.",
                  "Traveler Passport & Opinions: Stamped progress tracking and unfiltered traveler journals."
                ].map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-sm text-sandstone-200">
                    <span className="w-5 h-5 rounded-full bg-saffron-500/20 text-marigold-300 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5 border border-saffron-500/30">
                      ✓
                    </span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-2xl bg-white/10 border border-white/15 text-xs text-marigold-200 font-medium">
              100% focused on low-impact, respectful cultural immersion.
            </div>
          </div>

        </div>

        {/* Core Pillars */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-sandstone-200 text-center space-y-2">
            <span className="text-2xl">🌿</span>
            <h4 className="font-bold text-stone-900 text-sm">Bio-Engineering</h4>
            <p className="text-xs text-stone-500">Living root bridges & zero-waste valleys</p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-sandstone-200 text-center space-y-2">
            <span className="text-2xl">🛕</span>
            <h4 className="font-bold text-stone-900 text-sm">Sacred Monoliths</h4>
            <p className="text-xs text-stone-500">Subterranean shrines & floating pillars</p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-sandstone-200 text-center space-y-2">
            <span className="text-2xl">🎭</span>
            <h4 className="font-bold text-stone-900 text-sm">Endangered Crafts</h4>
            <p className="text-xs text-stone-500">River mask-makers & tile artisans</p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-sandstone-200 text-center space-y-2">
            <span className="text-2xl">🍲</span>
            <h4 className="font-bold text-stone-900 text-sm">Ancient Recipes</h4>
            <p className="text-xs text-stone-500">Woodfire tribal feasts & spice routes</p>
          </div>
        </div>

      </div>
    </section>
  );
};
