import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Heart, 
  Star, 
  Plus, 
  Trash2, 
  BookOpen, 
  Sparkles, 
  Award, 
  Calendar, 
  MessageSquare, 
  MapPin, 
  ArrowRight,
  Compass,
  Edit3
} from 'lucide-react';
import { destinations } from '../data/destinations';
import { playBellChime } from '../utils/audioPlayer';

export const MyJourney = ({
  visitedList = [],
  wishlist = [],
  userReviews = [],
  savedTrails = [],
  onOpenDetails,
  onRemoveWishlist,
  onRemoveVisited,
  onAddReview,
  onDeleteReview,
  currentUser
}) => {
  const [activeJourneyTab, setActiveJourneyTab] = useState('visited'); // 'visited', 'wishlist', 'trails'
  const [showLogModal, setShowLogModal] = useState(false);
  
  // Log form state
  const [selectedDestId, setSelectedDestId] = useState(destinations[0].id);
  const [rating, setRating] = useState(5);
  const [opinionText, setOpinionText] = useState('');
  const [secretAdvice, setSecretAdvice] = useState('');
  const [visitDate, setVisitDate] = useState(new Date().toISOString().split('T')[0]);
  const [mood, setMood] = useState('Spiritual & Peaceful 🪷');

  const totalGems = destinations.length;
  const visitedCount = visitedList.length;
  const progressPercent = Math.min(100, Math.round((visitedCount / totalGems) * 100));

  // Determine Explorer Rank
  let explorerRank = "Novice Wanderer 🌿";
  let rankColor = "text-stone-700 bg-sandstone-200";
  if (visitedCount >= 9) {
    explorerRank = "Master of Hidden India 🪷";
    rankColor = "text-purple-900 bg-purple-100 border border-purple-300";
  } else if (visitedCount >= 6) {
    explorerRank = "Sacred Pathfinder 🥇";
    rankColor = "text-amber-900 bg-amber-100 border border-amber-300";
  } else if (visitedCount >= 3) {
    explorerRank = "Offbeat Trailblazer 🥈";
    rankColor = "text-peacock-900 bg-peacock-100 border border-peacock-300";
  } else if (visitedCount >= 1) {
    explorerRank = "Curious Seeker 🥉";
    rankColor = "text-saffron-900 bg-saffron-100 border border-saffron-300";
  }

  const handleSaveLog = (e) => {
    e.preventDefault();
    if (!opinionText.trim()) return;

    const matchedDest = destinations.find(d => d.id === selectedDestId);
    if (!matchedDest) return;

    onAddReview({
      destinationId: matchedDest.id,
      destinationName: matchedDest.name,
      author: currentUser?.name || 'Explorer',
      rating,
      comment: opinionText.trim(),
      secretTip: secretAdvice.trim(),
      mood,
      date: new Date(visitDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    });

    playBellChime();
    setOpinionText('');
    setSecretAdvice('');
    setShowLogModal(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-16">
      
      {/* Traveler Passport Header Card */}
      <div className="bg-gradient-to-r from-sandstone-900 via-stone-900 to-sandstone-950 text-white rounded-3xl p-6 sm:p-10 border border-sandstone-700 shadow-2xl relative overflow-hidden mb-10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <span className="text-3xl">🪷</span>
              <div>
                <h2 className="font-serif text-2xl sm:text-4xl font-black text-white">
                  {currentUser ? `${currentUser.name}'s Journey Passport` : 'My Hidden India Passport'}
                </h2>
                <div className="flex items-center gap-2 mt-1">
                  <span className={`text-xs font-bold px-3 py-1 rounded-full ${rankColor}`}>
                    {explorerRank}
                  </span>
                  <span className="text-xs text-sandstone-300">
                    {visitedCount} of {totalGems} Secret Sites Explored
                  </span>
                </div>
              </div>
            </div>

            {/* Progress Gauge */}
            <div className="max-w-md pt-2">
              <div className="flex justify-between text-xs font-bold text-sandstone-300 mb-1.5">
                <span>Subcontinent Discovery Progress</span>
                <span className="text-saffron-400">{progressPercent}%</span>
              </div>
              <div className="w-full h-3 bg-white/10 rounded-full overflow-hidden p-0.5 border border-white/10">
                <div 
                  className="h-full bg-gradient-to-r from-saffron-500 via-marigold-500 to-emerald-400 rounded-full transition-all duration-700"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          </div>

          {/* Quick Action Button */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowLogModal(true)}
              className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-saffron-600 to-terracotta-600 hover:from-saffron-500 hover:to-terracotta-500 text-white font-bold text-xs sm:text-sm shadow-lg hover:scale-105 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Log Visited Place & Write Opinion</span>
            </button>
          </div>

        </div>
      </div>

      {/* Journey Tabs */}
      <div className="flex items-center justify-between border-b border-sandstone-200 mb-8 overflow-x-auto scrollbar-none">
        <div className="flex gap-2">
          <button
            onClick={() => setActiveJourneyTab('visited')}
            className={`flex items-center gap-2 px-5 py-3 border-b-2 font-bold text-sm transition-all ${
              activeJourneyTab === 'visited'
                ? 'border-saffron-600 text-saffron-700'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Places Visited & Opinions</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-sandstone-100 text-stone-700">
              {visitedList.length}
            </span>
          </button>

          <button
            onClick={() => setActiveJourneyTab('wishlist')}
            className={`flex items-center gap-2 px-5 py-3 border-b-2 font-bold text-sm transition-all ${
              activeJourneyTab === 'wishlist'
                ? 'border-saffron-600 text-saffron-700'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Heart className="w-4 h-4" />
            <span>Saved Wishlist</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-sandstone-100 text-stone-700">
              {wishlist.length}
            </span>
          </button>

          <button
            onClick={() => setActiveJourneyTab('trails')}
            className={`flex items-center gap-2 px-5 py-3 border-b-2 font-bold text-sm transition-all ${
              activeJourneyTab === 'trails'
                ? 'border-saffron-600 text-saffron-700'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>Saved Secret Trails</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-sandstone-100 text-stone-700">
              {savedTrails.length}
            </span>
          </button>
        </div>
      </div>

      {/* SECTION 1: VISITED PLACES & OPINIONS */}
      {activeJourneyTab === 'visited' && (
        <div className="space-y-6">
          {visitedList.length === 0 ? (
            <div className="bg-white rounded-3xl p-10 sm:p-16 text-center border border-sandstone-200/90 shadow-sm max-w-xl mx-auto space-y-4">
              <div className="w-16 h-16 rounded-full bg-saffron-100 text-saffron-600 flex items-center justify-center mx-auto text-2xl">
                🗺️
              </div>
              <h3 className="font-serif text-2xl font-bold text-stone-900">
                No places logged in your passport yet!
              </h3>
              <p className="text-sm text-stone-600 leading-relaxed">
                Have you been to Ziro Valley, Majuli Island, Unakoti, or Lepakshi? Mark them as visited or click below to log your opinions and tips.
              </p>
              <button
                onClick={() => setShowLogModal(true)}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-saffron-600 text-white font-bold text-sm shadow hover:bg-saffron-700 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Log Your First Visited Place</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {visitedList.map((dest) => {
                // Find opinions written by user for this destination
                const matchingReviews = userReviews.filter(r => r.destinationId === dest.id);

                return (
                  <div
                    key={dest.id}
                    className="bg-white rounded-3xl overflow-hidden border border-sandstone-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
                  >
                    <div>
                      {/* Image Header */}
                      <div className="relative aspect-[16/10] bg-sandstone-200">
                        <img
                          src={dest.image}
                          alt={dest.name}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                        <span className="absolute top-3 left-3 px-3 py-1 rounded-full bg-emerald-600 text-white text-xs font-bold shadow flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Visited & Stamped</span>
                        </span>

                        <div className="absolute bottom-3 left-3 right-3 text-white">
                          <h4 className="font-serif font-bold text-lg leading-tight">
                            {dest.name}
                          </h4>
                          <span className="text-xs text-amber-200">
                            {dest.state} · {dest.region}
                          </span>
                        </div>
                      </div>

                      {/* Traveler's Recorded Opinions */}
                      <div className="p-5 space-y-3">
                        {matchingReviews.length > 0 ? (
                          matchingReviews.map((rev, idx) => (
                            <div key={idx} className="p-3.5 rounded-2xl bg-sandstone-50 border border-sandstone-200/80 space-y-2">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center text-marigold-500">
                                  {Array.from({ length: rev.rating || 5 }).map((_, i) => (
                                    <Star key={i} className="w-3 h-3 fill-marigold-500" />
                                  ))}
                                </div>
                                <span className="text-[10px] text-stone-400 font-medium">{rev.date}</span>
                              </div>

                              <p className="text-xs text-stone-700 italic leading-relaxed">
                                "{rev.comment}"
                              </p>

                              {rev.secretTip && (
                                <div className="text-[11px] text-emerald-800 bg-emerald-50/80 p-2 rounded-xl font-medium">
                                  💡 <strong>Tip:</strong> {rev.secretTip}
                                </div>
                              )}
                            </div>
                          ))
                        ) : (
                          <div className="p-3 rounded-2xl bg-sandstone-50 text-center">
                            <p className="text-xs text-stone-500">No written opinion yet.</p>
                            <button
                              onClick={() => {
                                setSelectedDestId(dest.id);
                                setShowLogModal(true);
                              }}
                              className="text-xs text-saffron-600 font-bold hover:underline mt-1 block w-full"
                            >
                              + Add your opinion & advice
                            </button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Bottom Actions */}
                    <div className="p-4 bg-sandstone-50 border-t border-sandstone-100 flex items-center justify-between">
                      <button
                        onClick={() => onOpenDetails(dest)}
                        className="text-xs font-bold text-saffron-700 hover:text-saffron-800 flex items-center gap-1"
                      >
                        <BookOpen className="w-3.5 h-3.5" />
                        <span>View Story</span>
                      </button>

                      <button
                        onClick={() => onRemoveVisited(dest.id)}
                        className="text-stone-400 hover:text-rose-600 p-1.5 transition-colors"
                        title="Remove from Visited"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* SECTION 2: WISHLIST */}
      {activeJourneyTab === 'wishlist' && (
        <div className="space-y-6">
          {wishlist.length === 0 ? (
            <div className="bg-white rounded-3xl p-10 sm:p-16 text-center border border-sandstone-200/90 shadow-sm max-w-xl mx-auto space-y-4">
              <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto text-2xl">
                ❤️
              </div>
              <h3 className="font-serif text-2xl font-bold text-stone-900">
                Your wishlist is waiting to be filled!
              </h3>
              <p className="text-sm text-stone-600 leading-relaxed">
                Save secret places you dream of discovering. Browse our collection and click the heart icon on any destination card.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {wishlist.map((dest) => (
                <div
                  key={dest.id}
                  className="bg-white rounded-3xl overflow-hidden border border-sandstone-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
                >
                  <div>
                    <div className="relative aspect-[16/10] bg-sandstone-200">
                      <img
                        src={dest.image}
                        alt={dest.name}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                      <span className="absolute top-3 left-3 px-3 py-1 rounded-full bg-sandstone-900/80 backdrop-blur-md text-white text-xs font-semibold">
                        {dest.state}
                      </span>
                      <div className="absolute bottom-3 left-3 right-3 text-white">
                        <h4 className="font-serif font-bold text-lg leading-tight">
                          {dest.name}
                        </h4>
                        <span className="text-xs text-amber-200">
                          {dest.category}
                        </span>
                      </div>
                    </div>

                    <div className="p-5">
                      <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                        {dest.overview}
                      </p>
                    </div>
                  </div>

                  <div className="p-4 bg-sandstone-50 border-t border-sandstone-100 flex items-center justify-between">
                    <button
                      onClick={() => onOpenDetails(dest)}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-saffron-600 text-white font-semibold text-xs shadow hover:bg-saffron-700 transition-colors"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>Explore Story</span>
                    </button>

                    <button
                      onClick={() => onRemoveWishlist(dest.id)}
                      className="text-stone-400 hover:text-rose-600 p-1.5 transition-colors"
                      title="Remove from Wishlist"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SECTION 3: SAVED SECRET TRAILS */}
      {activeJourneyTab === 'trails' && (
        <div className="space-y-6">
          {savedTrails.length === 0 ? (
            <div className="bg-white rounded-3xl p-10 sm:p-16 text-center border border-sandstone-200/90 shadow-sm max-w-xl mx-auto space-y-4">
              <div className="w-16 h-16 rounded-full bg-saffron-100 text-saffron-600 flex items-center justify-center mx-auto text-2xl">
                🧭
              </div>
              <h3 className="font-serif text-2xl font-bold text-stone-900">
                No secret trails saved yet
              </h3>
              <p className="text-sm text-stone-600 leading-relaxed">
                Take our 3-question "Choose Your Secret Trail" quiz to generate customized itineraries tailored to your curiosity and timeframe!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {savedTrails.map((trail, idx) => (
                <div key={idx} className="bg-white rounded-3xl p-6 border border-sandstone-200 shadow-md space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold px-3 py-1 rounded-full bg-saffron-100 text-saffron-800">
                      {trail.durationText}
                    </span>
                    <span className="text-xs text-stone-500">
                      Season: {trail.idealSeason}
                    </span>
                  </div>

                  <h4 className="font-serif text-xl font-bold text-stone-900">
                    {trail.title}
                  </h4>
                  <p className="text-xs text-stone-600">
                    {trail.tagline}
                  </p>

                  <div className="space-y-2 pt-2">
                    {trail.itinerary.map((it, i) => (
                      <div key={i} className="text-xs text-stone-700 bg-sandstone-50 p-2.5 rounded-xl border border-sandstone-200/70">
                        <strong>{it.day}: {it.title}</strong>
                        <p className="text-stone-500 mt-0.5 line-clamp-1">{it.morning}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* LOG VISITED PLACE & WRITE OPINION MODAL */}
      {showLogModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex justify-center p-4 animate-fade-in">
          <div className="relative w-full max-w-lg bg-white rounded-3xl overflow-hidden shadow-2xl border border-sandstone-200 my-auto p-6 sm:p-8 space-y-5">
            
            <div className="flex items-center justify-between pb-3 border-b border-sandstone-100">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <h3 className="font-serif text-xl font-bold text-stone-900">
                  Record Progress & Write Opinion
                </h3>
              </div>
              <button
                onClick={() => setShowLogModal(false)}
                className="text-stone-400 hover:text-stone-600 font-bold p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveLog} className="space-y-4">
              {/* Select Destination */}
              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  Which Hidden Wonder Did You Visit?
                </label>
                <select
                  value={selectedDestId}
                  onChange={(e) => setSelectedDestId(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-sandstone-50 rounded-xl border border-sandstone-300 outline-none focus:border-saffron-500 font-medium"
                >
                  {destinations.map(d => (
                    <option key={d.id} value={d.id}>
                      {d.name} ({d.state})
                    </option>
                  ))}
                </select>
              </div>

              {/* Date & Rating */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-stone-700 block mb-1">
                    Date of Visit
                  </label>
                  <input
                    type="date"
                    value={visitDate}
                    onChange={(e) => setVisitDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-sandstone-50 rounded-xl border border-sandstone-300 outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-stone-700 block mb-1">
                    Your Rating
                  </label>
                  <div className="flex items-center gap-1 py-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setRating(star)}
                        className="text-marigold-500"
                      >
                        <Star className={`w-4 h-4 ${star <= rating ? 'fill-marigold-500' : 'text-stone-300'}`} />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Opinion */}
              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  Your Opinion & Feelings (What touched you most?)
                </label>
                <textarea
                  rows={3}
                  required
                  value={opinionText}
                  onChange={(e) => setOpinionText(e.target.value)}
                  placeholder="The mist rising from the bamboo groves, the chanting in the mud prayer halls, or the quiet stone carvings..."
                  className="w-full px-3.5 py-2.5 text-sm bg-sandstone-50 rounded-xl border border-sandstone-300 outline-none focus:border-saffron-500"
                />
              </div>

              {/* Secret Tip */}
              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  Insider Tip for Fellow Explorers (Optional)
                </label>
                <input
                  type="text"
                  value={secretAdvice}
                  onChange={(e) => setSecretAdvice(e.target.value)}
                  placeholder="e.g. Talk to the local elder at the tea stall for historical folk stories"
                  className="w-full px-3.5 py-2 text-xs bg-sandstone-50 rounded-xl border border-sandstone-300 outline-none focus:border-saffron-500"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-saffron-600 to-terracotta-600 text-white font-bold text-sm shadow hover:shadow-lg transition-all"
                >
                  Stamp Passport & Save Opinion
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
