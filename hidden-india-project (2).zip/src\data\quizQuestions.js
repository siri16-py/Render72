export const quizSteps = [
  {
    id: "interest",
    title: "What kind of India do you want to discover?",
    subtitle: "Select the calling that resonates most with your curiosity",
    options: [
      {
        id: "ancient",
        label: "Ancient mysteries and forgotten history",
        description: "5,000-year-old lost cities, monolithic rock carvings, and subterranean enigmas",
        icon: "Landmark",
        color: "border-amber-500 bg-amber-500/10 text-amber-900"
      },
      {
        id: "sacred",
        label: "Mythology and sacred places",
        description: "Cliffside gompas, world's highest Shiva shrine, and sacred springs of lore",
        icon: "Flame",
        color: "border-orange-500 bg-orange-500/10 text-orange-900"
      },
      {
        id: "nature",
        label: "Nature and hidden villages",
        description: "Living root bridges, whispering pine groves, and tribal bamboo landscapes",
        icon: "Trees",
        color: "border-emerald-500 bg-emerald-500/10 text-emerald-900"
      },
      {
        id: "culture",
        label: "Local culture, crafts and traditions",
        description: "River island mask-making, hand-stamped Athangudi tiles, and culinary heritage",
        icon: "Palette",
        color: "border-rose-500 bg-rose-500/10 text-rose-900"
      }
    ]
  },
  {
    id: "duration",
    title: "How long is your trip?",
    subtitle: "Tell us the rhythm of your secret journey",
    options: [
      {
        id: "day",
        label: "One day",
        description: "Quick deep dive escape into an offbeat wonder",
        icon: "Sun",
        color: "border-amber-400 bg-amber-50"
      },
      {
        id: "weekend",
        label: "2–3 days",
        description: "A weekend trail full of serene landscapes and slow village life",
        icon: "Calendar",
        color: "border-teal-500 bg-teal-50"
      },
      {
        id: "week",
        label: "One week",
        description: "An immersive expedition into remote tribal and mountainous realms",
        icon: "Compass",
        color: "border-indigo-500 bg-indigo-50"
      }
    ]
  },
  {
    id: "region",
    title: "Preferred region?",
    subtitle: "Which corner of the subcontinent whispers to you?",
    options: [
      {
        id: "anywhere",
        label: "Anywhere in India",
        description: "I'm ready for the most magical hidden secret wherever it hides",
        icon: "Globe",
        color: "border-saffron-500 bg-saffron-50"
      },
      {
        id: "south",
        label: "South India",
        description: "Gorges of Pennar, Chettinad mansions, and hanging pillars of Lepakshi",
        icon: "MapPin",
        color: "border-emerald-500 bg-emerald-50"
      },
      {
        id: "northeast",
        label: "North and Northeast India",
        description: "Ziro valley bamboo groves, Majuli masks, and Himalayan high shrines",
        icon: "Mountain",
        color: "border-cyan-500 bg-cyan-50"
      },
      {
        id: "west",
        label: "East and West India",
        description: "Harappan desert citadel of Dholavira and cosmic Lonar meteorite lake",
        icon: "SunMedium",
        color: "border-amber-500 bg-amber-50"
      }
    ]
  }
];

export const trailTemplates = {
  "ancient-south": {
    title: "The Stone Whisperers & Grand Canyon Odyssey",
    tagline: "Uncover Vijayanagara floating pillars and the colossal red chasm of Pennar",
    durationText: "2-3 Days Epic Heritage Trail",
    idealSeason: "October to March",
    destinations: ["lepakshi", "gandikota"],
    itinerary: [
      {
        day: "Day 1",
        title: "The Defying-Gravity Pillar of Lepakshi",
        morning: "Arrive at Lepakshi Veerabhadra Temple at 7:30 AM to catch the low sun illuminating the hanging pillar.",
        afternoon: "Slide a silk scarf under the floating granite pillar and gaze up at the 500-year-old ceiling frescoes of celestial dancers.",
        evening: "Pay homage to the monolithic Nandi bull carved from a single boulder, then journey onward to Gandikota under sunset skies."
      },
      {
        day: "Day 2",
        title: "The Red Chasm of Gandikota",
        morning: "Stand atop the 300-foot vertical granite cliffs as dawn mist lifts off the emerald Pennar River gorge.",
        afternoon: "Explore the medieval granaries, royal prison towers, and the Madhavaraya temple ruins without crowds.",
        evening: "Savor fiery Rayalaseema ragi mudde cooked over woodfire; stargaze along the canyon rim."
      }
    ],
    secretPackingTip: "Wear slip-on walking shoes (temples require bare feet, canyon requires grip) and carry a compass to test magnetic anomalies."
  },
  "culture-northeast": {
    title: "The Living Masks & Bamboo Guardians Expedition",
    tagline: "From Brahmaputra river monasteries to the sacred Apatani valleys",
    durationText: "5-7 Days Cultural Deep Dive",
    idealSeason: "November to April",
    destinations: ["majuli", "ziro-valley"],
    itinerary: [
      {
        day: "Day 1 & 2",
        title: "Brahmaputra River Passage & Mask Making",
        morning: "Cross the misty Brahmaputra on a wooden ferry to reach Majuli Island.",
        afternoon: "Sit alongside master artisans at Natun Samaguri Satra as they mold bamboo, cow dung, and river mud into mythological theater masks.",
        evening: "Listen to the evening Borgeet prayer chants echoing across the open-air wooden Namghar prayer halls."
      },
      {
        day: "Day 3 & 4",
        title: "The Apatani Valleys of Ziro",
        morning: "Scenic mountain drive into the pine-clad hills of Lower Subansiri to enter Ziro Valley.",
        afternoon: "Walk through the traditional stilt villages of Hong and Hari. Learn the indigenous fish-cum-paddy farming system.",
        evening: "Sip warm Apong millet wine by a family mud-hearth while elders share oral tales of the Donyi-Polo sun and moon spirits."
      }
    ],
    secretPackingTip: "Pack a lightweight rain poncho, reusable water flask, and an offline voice translator or notebook for interacting with village elders."
  },
  "sacred-northeast": {
    title: "The 9,999,999 Stone Faces of Lord Shiva",
    tagline: "A mystical pilgrimage into Tripura's jungle rock sanctuaries",
    durationText: "2-3 Days Spiritual Journey",
    idealSeason: "October to April",
    destinations: ["unakoti"],
    itinerary: [
      {
        day: "Day 1",
        title: "Journey to Dharmanagar Hills",
        morning: "Take the passenger train through green betel nut groves to Dharmanagar.",
        afternoon: "Ascend the forested steps of Raghunandan hills as giant stone faces emerge through jungle vines.",
        evening: "Meditate beside the roaring stream that washes the forehead of the 30-foot Unakotiswara Kal Bhairava sculpture."
      },
      {
        day: "Day 2",
        title: "Tribal Lore & Ashokastami Springs",
        morning: "Visit the three-eyed Ganesha bas-reliefs carved directly into the bedrock waterfall.",
        afternoon: "Taste authentic Tripuri Mui Borok prepared with fresh mountain herbs and fragrant sticky rice.",
        evening: "Participate in dusk earthen lamp lighting beneath the ancient banyan trees."
      }
    ],
    secretPackingTip: "Wear good rubber-tread sandals to walk on moist moss-covered stone steps safely."
  },
  "culture-south": {
    title: "The Athangudi Tile & Spice Mansion Trail",
    tagline: "Feast in 100-room merchant palaces and explore handmade craft villages",
    durationText: "2-3 Days Architecture & Culinary Trail",
    idealSeason: "October to March",
    destinations: ["chettinad"],
    itinerary: [
      {
        day: "Day 1",
        title: "The Palaces of Chettinad",
        morning: "Wander through the massive teak-pillared courtyards and Belgian glass galleries of Kanadukathan mansions.",
        afternoon: "Savor a traditional 18-course Chettinad lunch served on fresh plantain leaf with freshly ground black peppercorn curry.",
        evening: "Walk the quiet village streets to admire Art Deco and Dravidian fusion stone facades."
      },
      {
        day: "Day 2",
        title: "Artisans of Athangudi",
        morning: "Visit an ancestral Athangudi tile workshop. Watch craftsmen hand-pour vibrant mineral pigments into brass stencils.",
        afternoon: "Shop for vegetable-dyed Kandangi handloom cotton sarees directly from the weaver cooperatives.",
        evening: "Enjoy fresh filter coffee brewed with chicory in brass dabarah-tumblers at an antique heritage home."
      }
    ],
    secretPackingTip: "Keep luggage space for an Athangudi decorative souvenir tile and authentic roasted Chettinad spice blends."
  },
  "nature-northeast": {
    title: "The Bio-Engineering Roots & Living Clouds Trail",
    tagline: "Walk over living tree roots and witness Asia's cleanest village",
    durationText: "2-3 Days Botanical Marvel Trail",
    idealSeason: "September to May",
    destinations: ["mawlynnong-root-bridges"],
    itinerary: [
      {
        day: "Day 1",
        title: "Mawlynnong Village & Living Roots",
        morning: "Arrive in Mawlynnong, where every stone lane is lined with pitcher plants and orchid gardens.",
        afternoon: "Trek down the ancient stone path to the Riwai Living Root Bridge, trained by Khasi ancestors across the river.",
        evening: "Ascend the Sky Walk bamboo watchtower for panoramic views spanning the boundless plains of Bangladesh."
      },
      {
        day: "Day 2",
        title: "Crystal Waters & Waterfalls",
        morning: "Take an early morning dip in the turquoise crystal pools of Umngot River at Dawki.",
        afternoon: "Feast on Jadoh rice cooked with wild herbs in a Khasi family homestay.",
        evening: "Watch clouds billow up the deep gorges as dusk falls over the Meghalaya plateau."
      }
    ],
    secretPackingTip: "Bring quick-drying trekking gear and a waterproof phone pouch for river crossing."
  },
  "ancient-west": {
    title: "The White Desert Metropolis & Cosmic Crater Odyssey",
    tagline: "Indus civilization hydraulic geniuses and a 50,000-year-old cosmic impact lake",
    durationText: "4-5 Days Geological & Antiquity Trail",
    idealSeason: "November to February",
    destinations: ["dholavira", "lonar-crater"],
    itinerary: [
      {
        day: "Day 1 & 2",
        title: "The Harappan Enigma of Dholavira",
        morning: "Drive the magnificent 'Road to Heaven' through the glistening white salt desert of Kutch.",
        afternoon: "Walk through 5,000-year-old stone rainwater reservoirs that held millions of liters in an arid desert.",
        evening: "Stand before the 10 mysterious Indus script characters on the world's oldest monumental signboard."
      },
      {
        day: "Day 3 & 4",
        title: "The Hypervelocity Impact at Lonar",
        morning: "Trek down into the basalt crater rim of Lonar Lake surrounded by ancient 8th-century Hemadpanthi stone temples.",
        afternoon: "Observe rare extremophile microbial algae giving the water its emerald luminescence.",
        evening: "Stargaze beside the submerged Daityasudan temple where meteorite magnetic anomalies turn compass needles."
      }
    ],
    secretPackingTip: "Carry UV-protection sunglasses for the bright salt flats of Kutch and a small magnetic compass for Lonar."
  },
  "default": {
    title: "The Whispering Subcontinent Secret Trail",
    tagline: "A soul-stirring journey across India's forgotten wonders",
    durationText: "Curated 3-4 Days Experience",
    idealSeason: "October to April",
    destinations: ["ziro-valley", "unakoti", "chettinad", "gandikota"],
    itinerary: [
      {
        day: "Stage 1",
        title: "Living Traditions & Sacred Stone",
        morning: "Witness morning rituals and traditional crafts preserved untouched by commercial tourism.",
        afternoon: "Engage with local artisan families and discover indigenous building techniques passed down through generations.",
        evening: "Feast on authentic regional cuisine ground fresh on granite stone using age-old native spices."
      },
      {
        day: "Stage 2",
        title: "The Hidden Natural Amphitheater",
        morning: "Hike secret trails at sunrise before tourist crowds arrive to listen to pure nature soundscapes.",
        afternoon: "Learn local folklore and environmental stewardship practiced by native communities.",
        evening: "Gather under unpolluted night skies around a warm hearth with local hosts."
      }
    ],
    secretPackingTip: "Carry an open heart, respect local sacred etiquette, and avoid single-use plastics in fragile ecological zones."
  }
};
